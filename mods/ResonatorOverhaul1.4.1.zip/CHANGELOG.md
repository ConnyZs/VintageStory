# Resonator Overhaul — Changelog

Per-resonator volume, falloff radius, looping and room-only playback — edited with a
look-and-press-F panel, saved to the world and synced to every player. Also plays through the
Sound effects channel so it keeps working with in-game Music turned off.

---

## 1.4.1 — license

Added a License.txt to the mod package: CC BY-NC-ND 4.0 (© 2026 High Tech Games). Personal use
and sharing are welcome; for modifications, asset reuse or continued development, contact
High Tech Games. No gameplay changes.

## 1.4.0 — settings editable in-game through ConfigLib

With [ConfigLib](https://mods.vintagestory.at/configlib) installed, the mod's global settings now
have an in-game window (pause menu → Mods → Resonator Overhaul): the common ones — the Music-off
routing, ambient-music ducking, storm pitch-bending, and the default volume and radius for
unconfigured resonators — at the top, with the remaining defaults, room-audio tuning and the
radius limit in collapsible sections below. Changes apply **live**: the playback loop reads the
config every tick, so flipping a toggle is audible immediately, no world reload.

The three personal-audio toggles (Music-off routing, ducking, pitch-bending) are marked
**client-side** — on a multiplayer server every player can set their own without any privilege.
The defaults and the radius limit stay server-authoritative (editing those in-game needs
ConfigLib on the server and the *controlserver* privilege). ConfigLib remains entirely optional:
the window edits the same `ModConfig/resonatoroverhaul.json` as always, and nothing changes
without it installed. Per-resonator settings are untouched by all this — they stay on the F-key
panel, saved in the world.

## 1.3.0
- **New: "Play in room only".** A new switch in the resonator panel keeps a disc inside the enclosed
  room the resonator is standing in, so a jukebox in the tavern doesn't carry across the whole
  settlement. It uses the game's own room detection — the same one cellars and greenhouses use — so it
  understands your actual build: L-shaped rooms, stairwells and multi-floor interiors all work, and an
  open door doesn't break the seal (the game already treats an airtight door as sealing whether it's
  open or shut).
- Just past the room's edge the sound fades out rather than cutting, over `RoomEdgeFalloffBlocks`
  (new config option, default `3`) — so stepping through a doorway crossfades instead of clicking. Set
  it to `0` if you want strict containment.
- The room setting sits on top of the falloff radius rather than replacing it, so the radius slider
  still controls how far the disc carries *within* a large room.
- The panel now tells you whether the game considers this spot an enclosed room, and how big it is.
  Worth a look if the setting doesn't seem to do anything: the game's room detection only reaches about
  14 blocks from the resonator in each direction, so a great hall or a cave won't seal. When there's no
  enclosed room, the setting simply does nothing and the resonator plays at its normal falloff — set
  the new `RoomOnlySilentWithoutRoom` config option to `true` if you'd rather it stayed silent.
- Ambient music ducking now respects this too: a resonator you can't hear because you're outside its
  room no longer fades out your ambient track.

## 1.2.9
- **Fixed: ambient music could fade out near a resonator you couldn't even hear.** 1.2.8's ambient
  ducking triggered as soon as a resonator's disc audio was technically running, which happens the
  moment a disc is present in any loaded chunk — regardless of your distance from it, or even a
  per-resonator Volume set to 0. Ducking is now gated on the resonator's actual attenuated volume, so
  it only fades ambient music once the disc would truly be audible over it.

## 1.2.8
- **Fixed: resonator discs no longer play over the top of ambient/biome music.** The rewrite that let
  multiple resonators play at once (1.x) had them load their audio independently of the game's music
  engine, which also meant they stopped triggering the fade-out the game normally does when something
  claims its music slot — so ambient tracks kept playing underneath a resonator regardless of the
  `PlayWithMusicOff` setting. A playing resonator now explicitly fades out whatever ambient track the
  engine is playing (or tries to start) for as long as the disc is audible, without claiming the slot
  itself — so other resonators still aren't blocked. New config option `DuckAmbientMusic` (default
  `true`) turns this off if you'd rather have ambient music play through.

## 1.2.7
- **Fixed: mod failed to start on Vintage Story 1.22.5.** The 1.22.5 update renamed a parameter on the
  game's own resonator save/load method, which the mod hooks into by name. The mismatch made the hook
  throw on startup, and that aborted the whole mod — resonators reverted to vanilla single-track
  behaviour and your saved per-resonator settings were not applied. The hook now matches the new name.
- No settings or behaviour changes; existing saved settings are untouched.

## 1.2.6
- **Fixed: resonator settings no longer leak between worlds.** Settings were filed by block position
  alone, in a file shared by every world on the install — so a resonator standing at the same
  coordinates in a different world would inherit settings you had given a completely unrelated one.
  Settings are now filed under the savegame as well as the position, so each world keeps its own.
- Existing settings are carried over automatically the first time 1.2.6 loads a world; nothing to do.
  (If you ran an earlier version on more than one world in the same install, the migrated entries are
  assigned to the first world you load — worst case you re-set a resonator you had already set.)
- No other behaviour changes.

## 1.2.5
- **Fixed for real: discs now resume after a reconnect** — exit to menu and rejoin (or disconnect and
  reconnect without closing the game) and your resonators start playing again on their own, no full
  restart needed. This was the long-standing "only works after a full game restart" bug.
- The actual cause turned out to be deeper than the earlier attempts assumed: the mod's hooks into the
  resonator were being torn down every time you left a world, and a leftover "already set up" flag then
  stopped the mod from ever putting them back until the game was fully restarted. The mod now re-checks
  and reinstalls its own hooks on every world join, so it works no matter what strips them.
- Clean release: all the temporary `[RO-DIAG]` diagnostic logging from 1.2.2–1.2.4 has been removed.
- No settings or behaviour changes — same volume, falloff, looping and Music-off playback as before.

## 1.2.4
- Diagnostic build that pinned down the reconnect bug (the logging confirmed the mod's hooks were gone
  after a rejoin) and shipped the fix. Superseded by the clean 1.2.5 release above.

## 1.2.3
- Diagnostic build, round 2. The 1.2.2 logs proved playback is never even attempted after a reconnect,
  so this adds logging further upstream: a per-resonator heartbeat reporting what the client can see of
  the block (disc present? inventory synced?) and an explicit reason whenever a start is skipped.

## 1.2.2
- Diagnostic build. Adds temporary `[RO-DIAG]` logging to the disc start/load path to pin down why
  playback still doesn't resume after a reconnect. No behaviour changes intended; logging is stripped
  again once the cause is confirmed.

## 1.2.1
- **Attempted fix for: a disc with looping on wouldn't resume after reconnecting — only after a full
  game restart.** (Did not work — playback got worse, not better. Superseded; see 1.2.2 diagnostics.)
  Disc audio is loaded through the game's music engine, and that engine belongs to a single play session:
  leaving a world shuts down its background loading thread for good. This mod kept its reference to the
  engine for as long as the game was running, so after a reconnect it was still handing load requests to
  the dead engine from the previous session. Those requests were never picked up, so each resonator sat
  waiting forever on a song that could never arrive — and because it believed a load was already in
  progress, it never tried again. Restarting the game was the only way out, because that was the only
  thing that cleared the stale reference. The engine reference is now refreshed on every world join.
- Playback also no longer gets stuck permanently if a load fails to come back for any other reason: an
  unanswered load is now abandoned after 10 seconds and retried, so a resonator recovers on its own.

## 1.2.0
- **Multiple resonators can now play at the same time.** The game's music engine has a single global
  track slot and every resonator competed for it: whichever started last (usually because its chunk
  loaded in) silently killed the other, which then stayed dead until *its* chunk reloaded and it stole
  the slot right back. This masqueraded as a "minimum distance between resonators" (really the client's
  chunk-loading radius, hence the inconsistent 273/325-block measurements). Disc playback now bypasses
  the engine's track slot entirely — each resonator drives its own independent sound, so any number of
  them can play at once.
- **Breaking a resonator now clears its saved settings.** Settings are stored by block position and
  used to survive the block being broken, so a new resonator placed on the same spot inherited the old
  one's volume/falloff/loop. The entry is now deleted when the resonator is removed.
- *(This release also hoped to fix the rejoin/reconnect no-resume limitation. It did not — that had a
  separate cause, fixed in 1.2.1.)*

## 1.1.3
- **Fixed the full-volume blast on start/load.** The disc audio loads asynchronously and playback
  begins ~half a second later — before the per-tick volume/falloff code has run — so for a moment
  the song played at 100% volume with no distance attenuation (audible from ANY distance when the
  chunk loaded in, even 200+ blocks away). The sound now starts at 0% volume and the first tick
  raises it to the correct per-resonator volume/falloff.

## 1.1.2
- Clean release. Removed the temporary diagnostic logging used to track down the persistence/resume
  issues.

## 1.1.0 / 1.1.1
- **Auto-resume on load fixed.** Even with settings persisting, a resonator wouldn't restart its
  music on a fresh load: vanilla only resumes when its saved `isplaying` flag is true (unreliable),
  and the resonator deserializes *before* the client API is ready, so nothing triggers playback.
  Now the resonator force-resumes from the client tick loop whenever it holds a disc — so it reliably
  starts playing (and looping) on a fresh launch / first connect to a server.
- **Persistence reworked to a server-side JSON store** (`ModConfig/resonatoroverhaul-data.json`,
  keyed by block position), saved the instant you change a setting and loaded at server startup. The
  block-entity tree data is now only a client-sync transport and can no longer wipe a saved setting.
- Known limitation: an in-session rejoin (exit-to-menu → back, or disconnect → reconnect without
  closing the game) leaves the client music engine in a carried-over state and may not resume audio;
  a fresh launch / first connect works. To be revisited.

## 1.0.4
- **Per-resonator settings now actually persist across a relog** (the real fix). Root cause was
  not the loop logic at all — it was persistence. Settings reached the server and synced live
  fine, but on shutdown the engine disposes mod systems *before* its final "last tick" that flushes
  chunks to disk. The mod was unpatching Harmony in `Dispose()`, so that final save ran with our
  `ToTreeAttributes` hook already removed — the settings were never written, and every relog fell
  back to defaults (loop off). Fix: don't unpatch on shutdown. Verified via logging that settings
  are read back on load.
- (Temporary diagnostic logging was added in 1.0.3 to trace this and is removed again in 1.0.5.)

## 1.0.2 / 1.0.3
- Earlier attempts at the "looping doesn't survive relog" symptom (loop enforcement, then
  diagnostics). Superseded by the 1.0.4 persistence fix above.

## 1.0.2 (original note)
- **Looping actually survives a relog now** (the 1.0.1 attempt didn't). Root cause: after a relog
  the sound's OpenAL source is created *lazily*, only after the disc audio finishes loading — which
  is later than when the loop flag was being set, so the set silently no-op'd on a source that
  didn't exist yet. Worse, it still marked the sound's internal `ShouldLoop` as true, so 1.0.1's
  "only re-apply when it differs" check thought everything was fine and never corrected the real
  source. Loop is now applied unconditionally each client tick (which only runs once the sound is
  genuinely playing, so the source is valid). `SetLooping` just flips an OpenAL flag, so there's no
  restart or glitch.
- Requires the DLL (rebuild): needs the game closed to deploy.

## 1.0.1
- Attempted fix for looping not surviving a relog (superseded by 1.0.2 — did not work).

## 1.0.0
- Initial release.
- **Per-resonator settings:** each resonator remembers its own volume, falloff radius and loop
  on/off, stored on the block entity so they persist with the world save.
- **In-game editor:** look at a resonator and press **F** to open a panel with volume/falloff
  sliders and a loop toggle. Changes preview instantly and are saved on close. Key is rebindable
  under Controls → "Edit resonator settings".
- **Saved & synced:** settings ride the block's tree attributes, so they survive reloads, travel
  with the block, and are shared with every player on the server automatically.
- **Plays with Music off:** discs are routed through the Sound effects volume slider instead of the
  Music slider (configurable), so playback keeps working for players who run with game music down.
- **Config defaults** in `ModConfig/resonatoroverhaul.json` for new/unedited resonators, plus a cap
  on the maximum falloff radius.
- **Supersedes Resonator Tweaks:** if both are installed, Resonator Tweaks detects this mod and
  stands down, so they are safe to keep side by side.
