using System;
using System.Collections.Generic;
using System.IO;
using Newtonsoft.Json;
using Vintagestory.API.Common;
using Vintagestory.API.Common.Entities;
using Vintagestory.API.Config;
using Vintagestory.API.MathTools;
using Vintagestory.API.Server;

// Dashboard Stats Exporter — server-side. Tracks rich per-player stats and writes
// data/ModData/dashboardstats.json in the shape vsupdate.read_player_roster() expects:
//   { "generated": <unixSeconds>,
//     "players": [ { "uid","name","class","deaths","mobKills","playerKills",
//                    "playtimeHours","blocksTravelled","blocksBroken","blocksPlaced",
//                    "deepestY","lastSeen","gear":[...] }, ... ] }
// The web dashboard merges these by "uid" onto the playerdata roster for the Crew tab.
namespace DashboardStats
{
    public class GearItem
    {
        public string slot;   // clothes category (head/upperbody/lowerbody/foot/hand/neck/…) or slot index
        public string code;   // collectible code domain:path → maps to the worn texture
        public string name;   // display name
    }

    public class PlayerStat
    {
        public string uid;
        public string name;
        public string @class;
        public int deaths;
        public int mobKills;
        public int playerKills;
        public double playtimeHours;
        public double blocksTravelled;
        public int blocksBroken;
        public int blocksPlaced;
        public int deepestY = int.MaxValue;
        public long lastSeen;
        public List<string> gear = new List<string>();              // names (for the Crew tab list)
        public List<GearItem> gearDetail = new List<GearItem>();    // {slot,code,name} for the character render
        public Dictionary<string, string> skin = new Dictionary<string, string>();  // skin/hair/eye part codes
    }

    public class DashboardStatsModSystem : ModSystem
    {
        ICoreServerAPI sapi;
        readonly Dictionary<string, PlayerStat> stats = new Dictionary<string, PlayerStat>();
        readonly Dictionary<string, DateTime> joinedAt = new Dictionary<string, DateTime>();
        readonly Dictionary<string, Vec3d> lastPos = new Dictionary<string, Vec3d>();
        const string SaveKey = "dashboardstats:v1";
        const string OutFile = "dashboardstats.json";

        public override bool ShouldLoad(EnumAppSide side) => side == EnumAppSide.Server;

        public override void StartServerSide(ICoreServerAPI api)
        {
            sapi = api;
            LoadState();

            api.Event.PlayerNowPlaying += OnJoin;
            api.Event.PlayerDisconnect += OnLeave;
            api.Event.PlayerDeath      += OnPlayerDeath;
            api.Event.OnEntityDeath    += OnEntityDeath;
            api.Event.DidPlaceBlock    += OnPlace;
            api.Event.DidBreakBlock    += OnBreak;
            api.Event.GameWorldSave    += () => { FlushAll(); SaveState(); Export(); };

            // movement/depth sampler (10s) and a heavier export (every 2 min)
            api.Event.RegisterGameTickListener(_ => SampleMovement(), 10_000);
            api.Event.RegisterGameTickListener(_ => { FlushAll(); Export(); }, 120_000);

            api.Logger.Notification("[dashboardstats] loaded — exporting to ModData/" + OutFile);
        }

        // ---- events ----
        void OnJoin(IServerPlayer p)
        {
            joinedAt[p.PlayerUID] = DateTime.UtcNow;
            lastPos[p.PlayerUID] = p.Entity?.Pos?.XYZ;
            Touch(p); Export();
        }
        void OnLeave(IServerPlayer p) { Flush(p); Export(); }
        void OnPlayerDeath(IServerPlayer p, DamageSource src) { Get(p.PlayerUID, p.PlayerName).deaths++; Export(); }

        void OnEntityDeath(Entity entity, DamageSource src)
        {
            var killer = src?.GetCauseEntity() as EntityPlayer;
            if (killer == null) return;
            var pl = sapi.World.PlayerByUid(killer.PlayerUID) as IServerPlayer;
            if (pl == null) return;
            var s = Get(pl.PlayerUID, pl.PlayerName);
            if (entity is EntityPlayer) s.playerKills++; else s.mobKills++;
        }

        void OnPlace(IServerPlayer p, int blockId, BlockSelection bs, ItemStack stack) { Get(p.PlayerUID, p.PlayerName).blocksPlaced++; }
        void OnBreak(IServerPlayer p, int oldBlockId, BlockSelection bs) { Get(p.PlayerUID, p.PlayerName).blocksBroken++; }

        // ---- sampling ----
        void SampleMovement()
        {
            foreach (var pl in sapi.World.AllOnlinePlayers)
            {
                var p = pl as IServerPlayer;
                var pos = p?.Entity?.Pos?.XYZ;
                if (pos == null) continue;
                var s = Get(p.PlayerUID, p.PlayerName);
                if (lastPos.TryGetValue(p.PlayerUID, out var prev) && prev != null)
                {
                    double d = pos.DistanceTo(prev);
                    if (d < 400) s.blocksTravelled += d;     // ignore teleports
                }
                lastPos[p.PlayerUID] = pos;
                if ((int)pos.Y < s.deepestY) s.deepestY = (int)pos.Y;
            }
        }

        // ---- helpers ----
        PlayerStat Get(string uid, string name)
        {
            if (!stats.TryGetValue(uid, out var s)) { s = new PlayerStat { uid = uid, name = name }; stats[uid] = s; }
            if (!string.IsNullOrEmpty(name)) s.name = name;
            return s;
        }

        void Touch(IServerPlayer p)
        {
            var s = Get(p.PlayerUID, p.PlayerName);
            s.lastSeen = DateTimeOffset.UtcNow.ToUnixTimeSeconds();
            s.@class = p.Entity?.WatchedAttributes?.GetString("characterClass") ?? s.@class;
            ReadGear(p, s);
            s.skin = ReadSkin(p);
        }

        // applied skin parts (skin tone / hair / eyes) — read generically from WatchedAttributes
        // so we don't depend on the survival assembly. Lives under the "skinConfig" tree.
        Dictionary<string, string> ReadSkin(IServerPlayer p)
        {
            var outd = new Dictionary<string, string>();
            try
            {
                var tree = p.Entity?.WatchedAttributes?.GetTreeAttribute("skinConfig");
                var parts = tree?.GetTreeAttribute("appliedParts");
                if (parts != null)
                    foreach (var key in new[] { "baseskin", "haircolor", "hairbase", "hairextra",
                                                "mustache", "beard", "eyecolor", "skinoverlay", "wrinkles" })
                    {
                        var part = parts.GetTreeAttribute(key);
                        var code = part?.GetString("code");
                        if (!string.IsNullOrEmpty(code)) outd[key] = code;
                    }
            }
            catch (Exception e) { sapi.Logger.Warning("[dashboardstats] skin read: " + e.Message); }
            return outd;
        }

        void FlushAll() { foreach (var pl in sapi.World.AllOnlinePlayers) Flush(pl as IServerPlayer); }

        // fold the open session's real-time playtime into the total
        void Flush(IServerPlayer p)
        {
            if (p == null) return;
            Touch(p);
            if (joinedAt.TryGetValue(p.PlayerUID, out var since))
            {
                Get(p.PlayerUID, p.PlayerName).playtimeHours += Math.Max(0, (DateTime.UtcNow - since).TotalHours);
                joinedAt[p.PlayerUID] = DateTime.UtcNow;
            }
        }

        void ReadGear(IServerPlayer p, PlayerStat s)
        {
            var names = new List<string>();
            var detail = new List<GearItem>();
            try
            {
                var inv = p.InventoryManager?.GetOwnInventory(GlobalConstants.characterInvClassName);
                if (inv != null)
                    foreach (var slot in inv)
                    {
                        var st = slot?.Itemstack;
                        if (st == null) continue;
                        var nm = st.GetName();
                        if (!string.IsNullOrWhiteSpace(nm)) names.Add(nm);
                        string cat = null;
                        try { cat = st.Collectible?.Attributes?["clothescategory"]?.AsString(); } catch { }
                        detail.Add(new GearItem { slot = cat ?? "", code = st.Collectible?.Code?.ToString(), name = nm });
                    }
            }
            catch (Exception e) { sapi.Logger.Warning("[dashboardstats] gear read: " + e.Message); }
            s.gear = names;
            s.gearDetail = detail;
        }

        void Export()
        {
            try
            {
                var vals = new List<PlayerStat>(stats.Values);
                vals.Sort((a, b) => b.lastSeen.CompareTo(a.lastSeen));
                var players = new List<object>();
                foreach (var s in vals)
                    players.Add(new
                    {
                        s.uid, s.name, @class = s.@class, s.deaths, s.mobKills, s.playerKills,
                        playtimeHours = Math.Round(s.playtimeHours, 1),
                        blocksTravelled = (long)s.blocksTravelled,
                        s.blocksBroken, s.blocksPlaced,
                        deepestY = s.deepestY == int.MaxValue ? (int?)null : s.deepestY,
                        s.lastSeen, s.gear, s.gearDetail, s.skin
                    });
                var dir = sapi.GetOrCreateDataPath("ModData");
                File.WriteAllText(Path.Combine(dir, OutFile),
                    JsonConvert.SerializeObject(new { generated = DateTimeOffset.UtcNow.ToUnixTimeSeconds(), players }, Formatting.Indented));
            }
            catch (Exception e) { sapi.Logger.Error("[dashboardstats] export: " + e.Message); }
        }

        void SaveState()
        {
            try { sapi.WorldManager.SaveGame.StoreData(SaveKey, System.Text.Encoding.UTF8.GetBytes(JsonConvert.SerializeObject(stats))); }
            catch (Exception e) { sapi.Logger.Warning("[dashboardstats] save: " + e.Message); }
        }

        void LoadState()
        {
            try
            {
                var data = sapi.WorldManager.SaveGame.GetData(SaveKey);
                if (data == null) return;
                var loaded = JsonConvert.DeserializeObject<Dictionary<string, PlayerStat>>(System.Text.Encoding.UTF8.GetString(data));
                if (loaded != null) foreach (var kv in loaded) stats[kv.Key] = kv.Value;
            }
            catch (Exception e) { sapi.Logger.Warning("[dashboardstats] load: " + e.Message); }
        }
    }
}
