using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text.RegularExpressions;
using Newtonsoft.Json;
using Vintagestory.API.Common;
using Vintagestory.API.Common.Entities;
using Vintagestory.API.Config;
using Vintagestory.API.MathTools;
using Vintagestory.API.Server;

// Dashboard Stats Exporter — server-side. Tracks rich per-player stats and writes
// data/ModData/dashboardstats.json in the shape vsupdate.read_player_roster() expects:
//   { "generated": <unixSeconds>,
//     "players": [ { "uid","name","class","deaths","mobKills","playerKills",
//                    "mealsEaten","caloriesConsumed","foodCatCounts",
//                    "playtimeHours","blocksTravelled","blocksBroken","blocksPlaced",
//                    "deepestY","lastSeen","gear":[...] }, ... ] }
// The web dashboard merges these by "uid" onto the playerdata roster for the Crew tab.
namespace DashboardStats
{
    public class DeathEvent
    {
        public string playerName;
        public long   timestamp;   // unix seconds
        public string cause;
        public long   x, y, z;    // rounded world coords
    }

    public class GearItem
    {
        public string slot;   // clothes category (head/upperbody/lowerbody/foot/hand/neck/…) or slot index
        public string code;   // collectible code domain:path → maps to the worn texture
        public string name;   // display name
    }

    public class PlayerStat
    {
        public string uid;
        public string name;
        public string @class;
        public int deaths;
        public int mobKills;
        public int playerKills;
        public int mealsEaten;
        public int caloriesConsumed;
        public string lastMeal;
        public Dictionary<string, int> mealsByName  = new Dictionary<string, int>();
        public Dictionary<string, int> foodCatCounts = new Dictionary<string, int>();
        public Dictionary<string, int> deathCauses = new Dictionary<string, int>();
        public double playtimeHours;
        public double blocksTravelled;
        public int blocksBroken;
        public int blocksPlaced;
        public int deepestY = int.MaxValue;
        public long lastSeen;
        public List<string> gear = new List<string>();              // names (for the Crew tab list)
        public List<GearItem> gearDetail = new List<GearItem>();    // {slot,code,name} for the character render
        public Dictionary<string, string> skin = new Dictionary<string, string>();  // skin/hair/eye part codes
    }

    // Injected into each player entity on join. OnEntityReceiveSaturation fires directly
    // when the player eats — no polling needed, no attribute-key guessing.
    internal class MealTrackerBehavior : EntityBehavior
    {
        readonly Action<float, EnumFoodCategory, string> callback;

        public MealTrackerBehavior(Entity entity, Action<float, EnumFoodCategory, string> callback) : base(entity)
        {
            this.callback = callback;
        }

        public override string PropertyName() => "dashboardstats:mealtracker";

        public override void OnEntityReceiveSaturation(float saturation,
            EnumFoodCategory foodCat = EnumFoodCategory.Unknown,
            float saturationLossDelay = 10f,
            float nutritionGainMultiplier = 1f)
        {
            if (saturation <= 0f) return;
            // BlockMeal.Consume() fires ReceiveSaturation before it replaces the slot with an
            // empty bowl — so the active slot still holds the full meal with its display name.
            var player = (entity as EntityPlayer)?.Player as IServerPlayer;
            string mealName = player?.InventoryManager?.ActiveHotbarSlot?.Itemstack?.GetName() ?? "";
            callback(saturation, foodCat, mealName);
        }
    }

    public class DashboardStatsModSystem : ModSystem
    {
        ICoreServerAPI sapi;
        long startupTs;
        readonly Dictionary<string, PlayerStat> stats = new Dictionary<string, PlayerStat>();
        readonly Dictionary<string, DateTime> joinedAt = new Dictionary<string, DateTime>();
        readonly Dictionary<string, Vec3d> lastPos = new Dictionary<string, Vec3d>();
        // Compound meals (Expanded Foods) fire multiple OnEntityReceiveSaturation calls in the
        // same tick — one per nutrition component. We group events within a 500ms window as
        // one meal, and only record each food category once per meal to avoid "Vegetable ×4".
        readonly Dictionary<string, long> lastEatMs = new Dictionary<string, long>();
        readonly Dictionary<string, HashSet<string>> mealCats = new Dictionary<string, HashSet<string>>();
        readonly List<DeathEvent> deathLog = new List<DeathEvent>();
        const string SaveKey    = "dashboardstats:v1";
        const string DeathKey   = "dashboardstats:deaths";
        const string OutFile = "dashboardstats.json";

        public override bool ShouldLoad(EnumAppSide side) => side == EnumAppSide.Server;

        public override void StartServerSide(ICoreServerAPI api)
        {
            sapi = api;
            startupTs = DateTimeOffset.UtcNow.ToUnixTimeSeconds();
            LoadState();

            api.Event.PlayerNowPlaying += OnJoin;
            api.Event.PlayerDisconnect += OnLeave;
            api.Event.PlayerDeath      += OnPlayerDeath;
            api.Event.OnEntityDeath    += OnEntityDeath;
            api.Event.DidPlaceBlock    += OnPlace;
            api.Event.DidBreakBlock    += OnBreak;
            api.Event.GameWorldSave    += () => { FlushAll(); SaveState(); SaveDeathLog(); Export(); };
            LoadDeathLog();

            api.ChatCommands.Create("dashboardstats-resetfood")
                .WithDescription("Reset all food stats (mealsEaten, calories, mealsByName, foodCatCounts) for all players")
                .RequiresPrivilege(Privilege.controlserver)
                .HandleWith(_ => {
                    foreach (var s in stats.Values)
                    {
                        s.mealsEaten = 0;
                        s.caloriesConsumed = 0;
                        s.lastMeal = null;
                        s.mealsByName  = new Dictionary<string, int>();
                        s.foodCatCounts = new Dictionary<string, int>();
                    }
                    SaveState(); Export();
                    return TextCommandResult.Success("Food stats reset for all players.");
                });

            // Read-only sanity check, not a correction tool - see ComputeLogPlaytime's own
            // comment for why this deliberately does not overwrite anything. Reads server-main.log
            // (current + Archive/*), which can be several MB combined; fine for an admin-invoked
            // one-off but not something to call often.
            api.ChatCommands.Create("dashboardstats-logplaytime")
                .WithDescription("Report real connected-time per player computed from join/leave lines " +
                                 "in server-main.log (current + Archive/*), for comparing against the " +
                                 "live-tracked playtimeHours. Read-only - does not change any stored stat.")
                .RequiresPrivilege(Privilege.controlserver)
                .HandleWith(_ => {
                    var (totals, oldestLine, filesRead) = ComputeLogPlaytime();
                    if (filesRead == 0)
                        return TextCommandResult.Error("No server-main.log files found (checked " +
                                                        GamePaths.Logs + " and its Archive/ subfolder).");
                    if (totals.Count == 0)
                        return TextCommandResult.Success(
                            $"Parsed {filesRead} log file(s), oldest entry {oldestLine}, but found no complete join/leave pairs.");
                    var lines = totals.OrderByDescending(kv => kv.Value)
                        .Select(kv => $"{kv.Key}: {FormatPlaytime(kv.Value / 60.0)}");
                    return TextCommandResult.Success(
                        $"Log-derived playtime since {oldestLine} ({filesRead} file(s) parsed):\n" +
                        string.Join("\n", lines) +
                        "\n(This only covers time logs are retained for - almost certainly less than " +
                        "each player's full tracked history. Not a replacement for playtimeHours, a " +
                        "reference to sanity-check recent numbers against.)");
                });

            // movement/depth sampler (10s) and a heavier export (every 2 min)
            api.Event.RegisterGameTickListener(_ => SampleMovement(), 10_000);
            api.Event.RegisterGameTickListener(_ => { FlushAll(); Export(); }, 120_000);

            api.Logger.Notification("[dashboardstats] loaded — exporting to ModData/" + OutFile);
        }

        // ---- events ----
        void OnJoin(IServerPlayer p)
        {
            joinedAt[p.PlayerUID] = DateTime.UtcNow;
            lastPos[p.PlayerUID] = p.Entity?.Pos?.XYZ;
            // Add meal tracker behavior — fires OnEntityReceiveSaturation directly when food is eaten
            if (p.Entity != null)
                p.Entity.AddBehavior(new MealTrackerBehavior(p.Entity, (sat, cat, meal) => OnEat(p, sat, cat, meal)));
            Touch(p); Export();
        }

        void OnLeave(IServerPlayer p) { Flush(p); Export(); }

        void OnPlayerDeath(IServerPlayer p, DamageSource src)
        {
            var s = Get(p.PlayerUID, p.PlayerName);
            s.deaths++;
            if (s.deathCauses == null) s.deathCauses = new Dictionary<string, int>();
            var cause = DeathCause(src);
            s.deathCauses.TryGetValue(cause, out var prev);
            s.deathCauses[cause] = prev + 1;
            var pos = p.Entity?.Pos?.XYZ;
            deathLog.Insert(0, new DeathEvent {
                playerName = p.PlayerName,
                timestamp  = DateTimeOffset.UtcNow.ToUnixTimeSeconds(),
                cause      = cause,
                x = pos != null ? (long)pos.X : 0,
                y = pos != null ? (long)pos.Y : 0,
                z = pos != null ? (long)pos.Z : 0
            });
            if (deathLog.Count > 20) deathLog.RemoveRange(20, deathLog.Count - 20);
            Export();
        }

        void OnEntityDeath(Entity entity, DamageSource src)
        {
            if (entity is EntityPlayer) return;   // player-kills not tracked
            var killer = src?.GetCauseEntity() as EntityPlayer;
            if (killer == null) return;
            var pl = sapi.World.PlayerByUid(killer.PlayerUID) as IServerPlayer;
            if (pl == null) return;
            Get(pl.PlayerUID, pl.PlayerName).mobKills++;
        }

        void OnPlace(IServerPlayer p, int blockId, BlockSelection bs, ItemStack stack) { Get(p.PlayerUID, p.PlayerName).blocksPlaced++; }
        void OnBreak(IServerPlayer p, int oldBlockId, BlockSelection bs) { Get(p.PlayerUID, p.PlayerName).blocksBroken++; }

        void OnEat(IServerPlayer p, float saturation, EnumFoodCategory foodCat, string mealName)
        {
            var s = Get(p.PlayerUID, p.PlayerName);
            long nowMs = DateTimeOffset.UtcNow.ToUnixTimeMilliseconds();
            bool newMeal = !lastEatMs.TryGetValue(p.PlayerUID, out var last) || (nowMs - last) > 500;
            lastEatMs[p.PlayerUID] = nowMs;

            if (newMeal)
            {
                mealCats[p.PlayerUID] = new HashSet<string>();
                s.mealsEaten++;
                if (!string.IsNullOrWhiteSpace(mealName))
                {
                    s.lastMeal = mealName;
                    s.mealsByName.TryGetValue(mealName, out var prev);
                    s.mealsByName[mealName] = prev + 1;
                }
            }

            s.caloriesConsumed += (int)Math.Max(0f, saturation);

            if (foodCat != EnumFoodCategory.NoNutrition && foodCat != EnumFoodCategory.Unknown)
            {
                var key = foodCat.ToString();
                if (!mealCats.TryGetValue(p.PlayerUID, out var cats))
                    mealCats[p.PlayerUID] = cats = new HashSet<string>();
                if (cats.Add(key))
                {
                    s.foodCatCounts.TryGetValue(key, out var prev);
                    s.foodCatCounts[key] = prev + 1;
                }
            }
            Export();
        }

        // ---- sampling ----
        void SampleMovement()
        {
            foreach (var pl in sapi.World.AllOnlinePlayers)
            {
                var p = pl as IServerPlayer;
                var pos = p?.Entity?.Pos?.XYZ;
                if (pos == null) continue;
                var s = Get(p.PlayerUID, p.PlayerName);
                if (lastPos.TryGetValue(p.PlayerUID, out var prev) && prev != null)
                {
                    double d = pos.DistanceTo(prev);
                    if (d < 400) s.blocksTravelled += d;     // ignore teleports
                }
                lastPos[p.PlayerUID] = pos;
                if ((int)pos.Y < s.deepestY) s.deepestY = (int)pos.Y;
            }
        }

        string DeathCause(DamageSource src)
        {
            if (src == null) return "unknown";
            var killer = src.GetCauseEntity();
            if (killer != null)
            {
                if (killer is EntityPlayer) return "player";
                return killer.Code?.Path ?? "entity";
            }
            if (src.Source == EnumDamageSource.Fall)      return "fall";
            if (src.Source == EnumDamageSource.Drown)     return "drowning";
            if (src.Source == EnumDamageSource.Void)      return "void";
            if (src.Source == EnumDamageSource.Explosion) return "explosion";
            if (src.Source == EnumDamageSource.Suicide)   return "command";
            if (src.Type   == EnumDamageType.Fire)        return "fire";
            if (src.Type   == EnumDamageType.Heat)        return "heat";
            if (src.Type   == EnumDamageType.Poison)      return "poison";
            if (src.Type   == EnumDamageType.Electricity) return "lightning";
            if (src.Type   == EnumDamageType.Frost)       return "freezing";
            if (src.Type   == EnumDamageType.Suffocation) return "suffocation";
            if (src.Type   == EnumDamageType.Acid)        return "acid";
            return src.Source.ToString().ToLower();
        }

        // ---- helpers ----
        PlayerStat Get(string uid, string name)
        {
            if (!stats.TryGetValue(uid, out var s)) { s = new PlayerStat { uid = uid, name = name }; stats[uid] = s; }
            if (!string.IsNullOrEmpty(name)) s.name = name;
            return s;
        }

        void Touch(IServerPlayer p)
        {
            var s = Get(p.PlayerUID, p.PlayerName);
            s.lastSeen = DateTimeOffset.UtcNow.ToUnixTimeSeconds();
            s.@class = p.Entity?.WatchedAttributes?.GetString("characterClass") ?? s.@class;
            ReadGear(p, s);
            ReadBags(p, s);
            s.skin = ReadSkin(p);
        }

        // Export whatever occupies each of the player's backpack-equip slots (normally up to
        // 4) — typically "Leather backpack", but the Butchering mod also lets a carried dead
        // animal occupy one of these same slots, so this must NOT be limited to items that are
        // strictly "bags". Each occupied slot becomes a gearDetail entry "bag-1".."bag-N".
        //
        // This reads InventoryPlayerBackpacks' own `bagSlots` array (the EQUIP slots holding
        // the worn bag/carried items themselves), not BagInventory's private per-bag storage
        // contents — the dashboard wants "what's equipped in each backpack slot", not "what's
        // stored inside it". An earlier version filtered on GetCollectibleInterface<IHeldBag>()
        // (the check the game's own BagInventory.ReloadBagInventory() uses internally to decide
        // "is this a bag"), which is too narrow — it would silently drop a carried carcass since
        // that's not an IHeldBag. Filtering on gear-duplication instead — skip anything whose
        // code was already reported by ReadGear() — targets the actual confirmed bug (other
        // mods, e.g. Quivers and Sheaths, register extra wearable-container equip points on this
        // same array, and some of those slots echoed plain worn clothes) without assuming
        // anything about what a legitimate non-bag occupant looks like.
        void ReadBags(IServerPlayer p, PlayerStat s)
        {
            try
            {
                // InventoryPlayerBackpacks is internal in 1.22 (not in the public API) but still
                // exists at runtime. Access its bagSlots field via reflection to stay on the
                // public API surface everywhere else.
                var backpackInv = p.InventoryManager?.GetOwnInventory(GlobalConstants.backpackInvClassName);
                if (backpackInv == null) return;
                var bagSlots = backpackInv.GetType().GetField("bagSlots")?.GetValue(backpackInv) as ItemSlot[];
                if (bagSlots == null) return;
                var wornCodes = new HashSet<string>();
                foreach (var g in s.gearDetail) if (g.code != null) wornCodes.Add(g.code);
                int i = 0;
                foreach (var slot in bagSlots)
                {
                    i++;
                    var stack = slot?.Itemstack;
                    if (stack == null) continue;
                    var col = stack.Collectible;
                    if (col == null) continue;
                    var code = col.Code.ToString();
                    if (wornCodes.Contains(code)) continue;   // already reported as worn gear — skip the duplicate
                    s.gearDetail.Add(new GearItem { slot = $"bag-{i}", code = code, name = stack.GetName() });
                }
            }
            catch (Exception e) { sapi.Logger.Warning("[dashboardstats] bag read: " + e.Message); }
        }

        // applied skin parts (skin tone / hair / beard / eyes) — read generically from
        // WatchedAttributes so we don't depend on the survival assembly. The behavior
        // (EntityBehaviorExtraSkinnable) stores them under skinConfig.appliedParts as a flat
        // tree: partCode -> StringAttribute(variantCode). Iterating the tree also captures
        // modded skin parts. The render pipeline maps these to skin/hair/eye textures + shapes.
        Dictionary<string, string> ReadSkin(IServerPlayer p)
        {
            var outd = new Dictionary<string, string>();
            try
            {
                var tree = p.Entity?.WatchedAttributes?.GetTreeAttribute("skinConfig");
                var parts = tree?.GetTreeAttribute("appliedParts");
                if (parts != null)
                    foreach (var kv in parts)
                    {
                        var code = parts.GetString(kv.Key);
                        if (!string.IsNullOrEmpty(code)) outd[kv.Key] = code;
                    }
            }
            catch (Exception e) { sapi.Logger.Warning("[dashboardstats] skin read: " + e.Message); }
            return outd;
        }

        void FlushAll() { foreach (var pl in sapi.World.AllOnlinePlayers) Flush(pl as IServerPlayer); }

        // fold the open session's real-time playtime into the total
        void Flush(IServerPlayer p)
        {
            if (p == null) return;
            Touch(p);
            if (joinedAt.TryGetValue(p.PlayerUID, out var since))
            {
                Get(p.PlayerUID, p.PlayerName).playtimeHours += Math.Max(0, (DateTime.UtcNow - since).TotalHours);
                joinedAt[p.PlayerUID] = DateTime.UtcNow;
            }
        }

        void ReadGear(IServerPlayer p, PlayerStat s)
        {
            var names = new List<string>();
            var detail = new List<GearItem>();
            try
            {
                var inv = p.InventoryManager?.GetOwnInventory(GlobalConstants.characterInvClassName);
                if (inv != null)
                    foreach (var slot in inv)
                    {
                        var st = slot?.Itemstack;
                        if (st == null) continue;
                        var nm = st.GetName();
                        if (!string.IsNullOrWhiteSpace(nm)) names.Add(nm);
                        string cat = null;
                        try { cat = st.Collectible?.Attributes?["clothescategory"]?.AsString(); } catch { }
                        // clothescategory is a display attribute vanilla clothing sets, but vanilla's
                        // own armor items (armor.json/armor-hide.json) never set it, and mods that add
                        // armor via a Harmony/JSON-patched behavior on top of those items (e.g. Combat
                        // Overhaul's CombatOverhaul:Armor behavior) don't add it either - so armor was
                        // silently falling into slot="" here, invisible to the paper-doll/3D render as
                        // a distinct category regardless of which mod equipped it. ItemSlotCharacter.Type
                        // (EnumCharacterDressType - Head/UpperBody/.../ArmorHead/ArmorBody/ArmorLegs) is
                        // the game engine's own authoritative slot classification, set by the inventory
                        // itself rather than by whichever mod happens to own the item, so it's a solid
                        // fallback for any item - armor or otherwise - that never got a clothescategory.
                        if (string.IsNullOrEmpty(cat) && slot is ItemSlotCharacter charSlot
                            && charSlot.Type != EnumCharacterDressType.Unknown)
                            cat = charSlot.Type.ToString().ToLowerInvariant();
                        detail.Add(new GearItem { slot = cat ?? "", code = st.Collectible?.Code?.ToString(), name = nm });
                    }
            }
            catch (Exception e) { sapi.Logger.Warning("[dashboardstats] gear read: " + e.Message); }
            s.gear = names;
            s.gearDetail = detail;
        }

        void Export()
        {
            try
            {
                var vals = new List<PlayerStat>(stats.Values);
                vals.Sort((a, b) => b.lastSeen.CompareTo(a.lastSeen));
                var players = new List<object>();
                foreach (var s in vals)
                    players.Add(new
                    {
                        s.uid, s.name, @class = s.@class, s.deaths, s.mobKills,
                        s.mealsEaten, s.caloriesConsumed, s.lastMeal,
                        mealsByName   = s.mealsByName   ?? new Dictionary<string, int>(),
                        foodCatCounts = s.foodCatCounts ?? new Dictionary<string, int>(),
                        deathCauses = s.deathCauses ?? new Dictionary<string, int>(),
                        playtimeHours = Math.Round(s.playtimeHours, 1),
                        playtimeFormatted = FormatPlaytime(s.playtimeHours),
                        blocksTravelled = (long)s.blocksTravelled,
                        s.blocksBroken, s.blocksPlaced,
                        deepestY = s.deepestY == int.MaxValue ? (int?)null : s.deepestY,
                        s.lastSeen, s.gear, s.gearDetail, s.skin
                    });
                // explicit list of who's actually connected right now (accurate online roster)
                var online = new List<string>();
                foreach (var pl in sapi.World.AllOnlinePlayers)
                    if (pl != null && !string.IsNullOrEmpty(pl.PlayerName)) online.Add(pl.PlayerName);
                object lastAccident = deathLog.Count > 0 ? (object)deathLog[0] : null;
                var dir = sapi.GetOrCreateDataPath("ModData");
                File.WriteAllText(Path.Combine(dir, OutFile),
                    JsonConvert.SerializeObject(new { generated = DateTimeOffset.UtcNow.ToUnixTimeSeconds(), startup_ts = startupTs, online, lastAccident, players }, Formatting.Indented));
            }
            catch (Exception e) { sapi.Logger.Error("[dashboardstats] export: " + e.Message); }
        }

        // "H:MM", e.g. 123:07 for 123 hours 7 minutes. playtimeHours already carries full
        // precision internally (only the exported raw-hours field is rounded to 1 decimal),
        // so this reads minute-accurate rather than compounding that rounding.
        static string FormatPlaytime(double hours)
        {
            int totalMinutes = Math.Max(0, (int)Math.Round(hours * 60));
            return $"{totalMinutes / 60}:{totalMinutes % 60:D2}";
        }

        static readonly Regex JoinLineRe = new Regex(
            @"^(\d{1,2})\.(\d{1,2})\.(\d{4}) (\d{2}):(\d{2}):(\d{2}) \[Event\] (.+?) \[.*?\]:\d+ joins\.$",
            RegexOptions.Compiled);
        static readonly Regex LeftLineRe = new Regex(
            @"^(\d{1,2})\.(\d{1,2})\.(\d{4}) (\d{2}):(\d{2}):(\d{2}) \[Event\] Player (.+?) left\.$",
            RegexOptions.Compiled);

        // Sums real connected-minutes per player name from join/leave lines across every
        // server-main.log this server still has on disk (current + Archive/*), oldest first.
        //
        // Deliberately read-only / report-only, not a "fix playtimeHours" tool: the live
        // tracker (playtimeHours) has been accumulating since this mod was first installed,
        // but log rotation only keeps a few weeks of Archive/ history - so a log-derived
        // total is always a partial-period number, never comparable 1:1 to the full
        // accumulated total. Blindly overwriting playtimeHours with this would silently
        // discard everything tracked before the oldest surviving archive. If you want to use
        // this for an actual correction, do it by hand with dashboardstats-resetfood-style
        // direct attribute edits, informed by what this reports - not automatically here.
        //
        // A session still open at the end of a file (server crashed / log rotated without a
        // clean "left" line) is closed at that file's own last timestamp as a documented
        // approximation, not carried across files.
        (Dictionary<string, double> totals, string oldestLine, int filesRead) ComputeLogPlaytime()
        {
            var totals = new Dictionary<string, double>();
            string oldestLine = null;
            int filesRead = 0;
            try
            {
                var files = new List<string>();
                var mainLog = Path.Combine(GamePaths.Logs, "server-main.log");
                if (File.Exists(mainLog)) files.Add(mainLog);
                var archiveDir = Path.Combine(GamePaths.Logs, "Archive");
                if (Directory.Exists(archiveDir))
                    files.AddRange(Directory.GetDirectories(archiveDir)
                        .Select(d => Path.Combine(d, "server-main.log"))
                        .Where(File.Exists));
                // Archive folder names are timestamp-prefixed (e.g. 2026-08-16_22_32_09) so
                // this sorts oldest-first; the live server-main.log sorts last, which is
                // correct (it's always the most recent).
                files.Sort(StringComparer.Ordinal);

                foreach (var file in files)
                {
                    var openSessions = new Dictionary<string, DateTime>();
                    DateTime lastTs = DateTime.MinValue;
                    foreach (var line in File.ReadLines(file))
                    {
                        var joinMatch = JoinLineRe.Match(line);
                        var leftMatch = joinMatch.Success ? null : LeftLineRe.Match(line);
                        if (!joinMatch.Success && (leftMatch == null || !leftMatch.Success)) continue;

                        var m = joinMatch.Success ? joinMatch : leftMatch;
                        if (!DateTime.TryParse(
                                $"{m.Groups[3].Value}-{m.Groups[2].Value}-{m.Groups[1].Value} " +
                                $"{m.Groups[4].Value}:{m.Groups[5].Value}:{m.Groups[6].Value}",
                                out var ts))
                            continue;
                        // files (and lines within a file) are processed oldest-first, so the
                        // first match overall is the oldest - no need to track a running min.
                        if (oldestLine == null) oldestLine = ts.ToString("yyyy-MM-dd HH:mm");
                        if (ts > lastTs) lastTs = ts;

                        var playerName = m.Groups[7].Value;
                        if (joinMatch.Success)
                        {
                            openSessions[playerName] = ts;
                        }
                        else if (openSessions.TryGetValue(playerName, out var joinTs))
                        {
                            totals.TryGetValue(playerName, out var prev);
                            totals[playerName] = prev + Math.Max(0, (ts - joinTs).TotalMinutes);
                            openSessions.Remove(playerName);
                        }
                    }
                    // Close anything still "open" at end-of-file against that file's own last timestamp.
                    foreach (var kv in openSessions)
                    {
                        totals.TryGetValue(kv.Key, out var prev);
                        totals[kv.Key] = prev + Math.Max(0, (lastTs - kv.Value).TotalMinutes);
                    }
                    filesRead++;
                }
            }
            catch (Exception e) { sapi.Logger.Warning("[dashboardstats] log playtime parse: " + e.Message); }
            return (totals, oldestLine, filesRead);
        }

        void SaveState()
        {
            try { sapi.WorldManager.SaveGame.StoreData(SaveKey, System.Text.Encoding.UTF8.GetBytes(JsonConvert.SerializeObject(stats))); }
            catch (Exception e) { sapi.Logger.Warning("[dashboardstats] save: " + e.Message); }
        }

        void LoadState()
        {
            try
            {
                var data = sapi.WorldManager.SaveGame.GetData(SaveKey);
                if (data == null) return;
                var loaded = JsonConvert.DeserializeObject<Dictionary<string, PlayerStat>>(System.Text.Encoding.UTF8.GetString(data));
                if (loaded != null) foreach (var kv in loaded) stats[kv.Key] = kv.Value;
            }
            catch (Exception e) { sapi.Logger.Warning("[dashboardstats] load: " + e.Message); }
        }

        void SaveDeathLog()
        {
            try { sapi.WorldManager.SaveGame.StoreData(DeathKey, System.Text.Encoding.UTF8.GetBytes(JsonConvert.SerializeObject(deathLog))); }
            catch (Exception e) { sapi.Logger.Warning("[dashboardstats] save deaths: " + e.Message); }
        }

        void LoadDeathLog()
        {
            try
            {
                var data = sapi.WorldManager.SaveGame.GetData(DeathKey);
                if (data == null) return;
                var loaded = JsonConvert.DeserializeObject<List<DeathEvent>>(System.Text.Encoding.UTF8.GetString(data));
                if (loaded != null) { deathLog.Clear(); deathLog.AddRange(loaded); }
            }
            catch (Exception e) { sapi.Logger.Warning("[dashboardstats] load deaths: " + e.Message); }
        }
    }
}
