Simple mod patching out the clothier trait being a requirement to craft sewing kits.
Anybody can use sewing kits to craft certain modded recipes as well as repair armor without needing a tailor.
