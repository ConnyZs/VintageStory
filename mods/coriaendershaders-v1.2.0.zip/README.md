# Coriaender Shaders
This is my mod for adding shader based visual effects to the game which adds lighting and reflection effects to water surfaces, cloud shadows, and simplified shadow maps to extend shadows to the full draw distance.
## Features
### Water Surface Shader
* Layers visual effects onto surface water. Some general lighting such as fresnel and specular effects, as well as reflection systems and a randomized wave system.  
	* Skybox reflections
		* Uses a cubemap to add reflections of the sky from any direction.
	* Screen space reflections
		* Uses ray marching to reflect everything else, but is limited to what's visible on screen. Settings allow for balancing fidelity and performance.
### Cloud Shadows
* Builds a shadow map based on the clouds for the game to reference when adding shadows.
### Terrain Shadows
* Renders cascaded shadow maps for loaded terrain.
## Compatibility & Dependency
The mod updated for game version 1.22. Since 1.22 changed a couple rendering things mod version 1.2+ won't work with older versions of the game.

Cloud shadows requires OpenGL 4.3, and Terrain shadows requires OpenGL 4.6. You can look up whether your graphics card supports it in [this database](https://opengl.gpuinfo.org/).  

Even if your graphics card supports OpenGL 4.6, on some platforms the game will set the setting 'glContextVersion' to 4.3 and refuse to load the mod. You'll need to go to clientsettings.json in the VintageStoryData directory and change it to 4.6.   

Currently Intel Arc drivers may not be supported and are being investigated. Specifically documentation claims to support ARB_indirect_parameters but I'm getting ExecutionEngineException when MultiDrawArraysIndirectCount is called.  

Using the settings UI requires the mod [VSImGUI](https://mods.vintagestory.at/imgui) be installed, but it isn't required and the settings can be changed in the modconfig directly.

This mod makes changes to many of the game's base shaders by replacing code at run time. It uses pattern matching so could fail if specific lines are changed, and probably won't work at all if a mod replaces or disabled base game shaders.
## Settings
The following settings can be changed in the modconfig file (\VintagestoryData\ModConfig\CoriaenderShaders.json) or by clicking 'save' from the in game UI. To reset settings to defaults, delete the mod's config file.
* SettingsGUIHotkey
	* Default K
	* Hotkey for opening settings GUI if VSImGUI is installed. Can only be changed in the config file, not in game.
### Water Reflections
* WaterEffectsEnabled
	* Enable/disable all water and reflection effects.
* reflectionStrength
	* Default 0.3
	* Directly adjust final alpha (visibility) of effects.
* SkyboxReflectionsEnabled
	* Reflect the sky and clouds.
* WavesEnabled
	* Simulate waves on the water surface.
#### Screen Space Reflections
* SSREnabled
	* Reflect the scene based on what is on screen.
* SSR Settings
    * SSREdgeAdjustEnabled 
	    * As the camera is pitched down the perspective shift causes some SSR rays near the edge of the screen to miss, and the abrupt transition to sky can be very noticeable. This pulls SSR to the edge a bit to cover that contrast, but doing so causes some sliding motion, so you can turn that off here if you prefer. No effect on performance.  
        <img src="https://codeberg.org/Corble/CoriaenderShaders/raw/branch/development/Images/edgeadjust.jpg" width=500>
	* Stride
	    * Default 2
		* How many pixels between samples while ray marching SSR. Increasing value will progressively introduce noise and banding but will greatly improving performance, with diminishing returns.  
        <img src="https://codeberg.org/Corble/CoriaenderShaders/raw/branch/development/Images/stridecompare0.jpg" width=500>
	* maxSteps
		* Set to -1 to default to screen width.
		* The max pixel length of each ray for SSR. Most rays don't travel the full distance, so only a marginal effect on performance. 
	*	maxDistance
		* Set to -1 to default to twice the draw distance.
		* The max world space length of each ray for SSR. Low values can give a small performance improvement by removing most reflections, but rays are clipped to the view distance so a higher value won't change performance.
### Shadows
* ShadowEffectsEnabled
  * Enable/disable all shadow effects.
#### Cloud Shadows
* CloudShadowsEnabled
  * Cast cloud shadows. The only shadow effect currently.
* CloudShadowStyle = 1
  * Whether to blur shadows (1) or not (0).
* CloudShadowMax = 0.4
  * Default 40%
  * The darkest cloud shadows can get, from 0 (no shadows) to 1 (complete darkness).  
  <img src="https://codeberg.org/Corble/CoriaenderShaders/raw/branch/development/Images/cloudshadowoptions.jpg" width=500>
#### Terrain Shadows
* TerrainShadowsEnabled
  * Have most terrain in the game cast shadows.  
* TerrainShadowMax
  * Default 50%
  * The darkest terrain shadows can get, from 0 (no shadows) to 1 (complete darkness). Shadows match the game's intensity adjustments for time of day regardless of this setting.  
* CascadeCount
  * The number of shadowmap cascades to draw, meaning how far from the player shadows will be cast. Can be 1-4, with 4 requiring ExtendShadowmapCascades to be active.  
* ExtendShadowmapCascades
  * Whether cascades should have three or four sections. More sections can improve cascade resolution even if not drawing all four.  
<img src="https://codeberg.org/Corble/CoriaenderShaders/raw/branch/development/Images/extendcascades.jpg" width=500>
* MixWithBaseShadows
  * Whether to draw shadows where the game is already doing so. Generally the game shadows are higher resolution and look better, but don't render distant terrain which can leave a bright area around the player.  
<img src="https://codeberg.org/Corble/CoriaenderShaders/raw/branch/development/Images/dontmixwithbase.jpg" width=500>
## Known Issues
Fixes or improvements I'd like to implement but have not.  
* Terrain shadows can pop in, or load only part or none of a chunk  
  * Chunk data is loaded by copying the base game's homework, so shadow loading is delayed if there aren't enough multithreading resources and sometimes misses chunks entirely.  
  * The long term fix is to write an autonomous loading system, but I've never written server side code so I started with the more familiar if flawed option.  
* More chunks are loaded/rendered than needed  
  * The system is written with LOD and occulsion culling in mind, but they are not implemented. This means it scales with visible chunks, which becomes a bottleneck for increasing view distance.  
* Reflections are drawn over transparent objects
  * The mod doesn't use the game's OIT "revealage" because it is shared between water and transparent objects, meaning I need to build out a process for tracking transparent revealage independently.
* There is color banding on the sun specular reflection
  * Adding some dithering will make this look better.

