#version 430
//! #define GBUFFER_UNIT 0
//! #define CAMERADEPTH_UNIT 1
//! #define MAINCOLOR_UNIT 2
//! #define GLOWCOLOR_UNIT 3
//! #define SKYCUBEMAP_UNIT 4
//! #define SHADOWMAPFAR_UNIT 5 
//! #define TEXCOLOR_LOCATION 0

#include screenuniformbuffer.ash
#include camerauniformbuffer.ash

in vec3 eyeDirection;

uniform int skyboxReflectionsEnabled;

layout(binding = SHADOWMAPFAR_UNIT) uniform sampler2DShadow shadowMapFar;
layout(binding = GBUFFER_UNIT) uniform sampler2D gBufferIn;
layout(binding = CAMERADEPTH_UNIT) uniform sampler2D cameraDepth;
layout(binding = MAINCOLOR_UNIT) uniform sampler2D mainColor;
layout(binding = GLOWCOLOR_UNIT) uniform sampler2D glowColor;
layout(binding = SKYCUBEMAP_UNIT) uniform samplerCube skyCubeMap;

uniform float reflectionStrength;

uniform float daylight;
uniform vec3 sunColor;
uniform float cameraUnderwater;
uniform float viewDistance;
uniform mat4 cstoshadowMatrix;

uniform vec3 waterMurkinessColor; // = vec3(0.05752, 0.19962, 0.17963);

layout(location = TEXCOLOR_LOCATION) out vec4 texColor;

/* gBuffer Input
rg - reflection normal x,y || SSR pixel coord x,y (if hit); g integral==1: is rain ripple
b - integral: fresnel angle-58, fractal: specular angle in radians, sign: sky exposed
a - camera space depth; 0: do not draw; sign: sign(reflection normal z)
*/
void main() {
    vec2 UV = gl_FragCoord.xy / screen_uniforms.screenSize;
    float underwater = cameraUnderwater > 0.7? 1 : 0;
    #if CS_UNDERWATER_ENABLED == 0
    if(underwater == 1) { discard; }
    #endif

    vec4 gBufferData = texelFetch(gBufferIn, ivec2(gl_FragCoord.xy), 0);
    if(gBufferData.a == 0) { discard; } // Not water

    float fresnelTheta = radians(floor(abs(gBufferData.b)) + 58);
    float specularTheta = fract(abs(gBufferData.b));

    bool ssrHit = gBufferData.r > 1 || gBufferData.g > 2;
    ivec2 ssrPixelHit = ssrHit? ivec2(gBufferData.rg) : ivec2(0);

    vec3 csPosition = eyeDirection * abs(gBufferData.a);
    vec3 wsPosition = (camera_uniforms.invModelViewMatrix * vec4(csPosition,0)).xyz;
    vec3 wsNorm = normalize(wsPosition);
    vec4 shadowSpacePosition = cstoshadowMatrix * vec4(csPosition, 1);
    float sunVisible = textureProj(shadowMapFar, shadowSpacePosition);
    float distanceToPlayer = length(wsPosition.xz);
    //float waterDepth = -csPosition.z - texelFetch(cameraDepth, ivec2(gl_FragCoord.xy), 0).r;

    bool skyHit = !ssrHit && (sunVisible == 1 || sign(gBufferData.b) > 0);
    float csDirY = fract(abs(gBufferData.g)) * sign(gBufferData.g);
	float z = skyHit? sqrt(1 - pow(gBufferData.r, 2) - pow(csDirY, 2)) * sign(gBufferData.a) : 0;
    vec3 csReflectionDir = vec3(gBufferData.r, csDirY, z);
	vec3 skyViewDirection = skyHit? (camera_uniforms.invModelViewMatrix * vec4(csReflectionDir, 0)).xyz : vec3(0);

    // Underwater refraction. Refraction looking into water would require replacing the water rendering entirely
    // Math fails at very shallow depths, so fake it for the first ~0.4
    float sceneDepth = underwater > 0? texelFetch(cameraDepth, ivec2(gl_FragCoord.x, gl_FragCoord.y *(1 - 0.05 * smoothstep(0.0, 1.0, wsPosition.y))), 0).r : -4;
    bool refractionHit = (sceneDepth > -csPosition.z - 1 && sceneDepth < viewDistance) || underwater * length(wsPosition.xz) > 30? true : false;
    if(!refractionHit && wsPosition.y > 0.4 && length(wsPosition.xz) > 2) {
		vec3 a = 1.02*(wsNorm + skyViewDirection)/2;
		vec3 b = -sqrt(1 - pow(length(a),2))*(skyViewDirection-wsNorm)/(2*cos(fresnelTheta));
		vec3 wsRefractionDir = a + b;
        vec4 refractionPixelPos = camera_uniforms.worldToPixelMatrix * vec4(wsRefractionDir * viewDistance, 0);
        ivec2 refractionPixel = ivec2(refractionPixelPos.xy / refractionPixelPos.w);
        refractionPixel.x = min(max(refractionPixel.x, 0), screen_uniforms.screenSize.x - 1);
        refractionPixel.y = min(max(refractionPixel.y, 0), screen_uniforms.screenSize.y - 1);
        float refractDepth = texelFetch(cameraDepth, refractionPixel, 0).r;
        refractionHit = (refractDepth > 0 - 1 && refractDepth < viewDistance);
    }
    skyViewDirection.y *= sign(skyViewDirection.y);
    if(!ssrHit && skyViewDirection.y <= 0 && !refractionHit) { discard; }

    texColor = ssrHit? texelFetch(mainColor, ssrPixelHit, 0)
             : refractionHit? mix(texture(mainColor, UV), vec4(waterMurkinessColor, 1), smoothstep(0, 1, wsPosition.y))
             : skyboxReflectionsEnabled == 1 && skyHit? texture(skyCubeMap, skyViewDirection)
             : texture(mainColor, UV);

    float skyGlow = skyboxReflectionsEnabled == 1 && skyHit? texColor.a : 0;
    float ssrGlow = ssrHit? texelFetch(glowColor, ssrPixelHit, 0).r : 0;
    texColor.rgb = mix(texColor.rgb, waterMurkinessColor, 0.4 * underwater);
    texColor.a = 1;

    // Get a more generic sky color to help with having the reflection better match the perceived sky
    vec3 skyColor = texture(skyCubeMap, 0.5 * (wsNorm + vec3(0, 1, 0))).xyz;
    skyColor = skyHit? mix(skyColor, texColor.rgb, 0.9) : skyColor;
    float cloudCover = smoothstep(0.0, 0.75, 1 - skyColor.g / max(skyColor.b, skyColor.r));

    // Color and lighting
    bool rainy = !ssrHit && abs(gBufferData.g) >= 1;
    float fresnel = pow(1 - cos(fresnelTheta), 5);
    float sunSpecular = sunVisible == 1 && specularTheta >= 0? pow(cos(specularTheta), underwater < 0? 900 : 10 + 170 * smoothstep(0.01, 0.4, camera_uniforms.sunPosition.y)) : 0;
    if(underwater < 1) {
        // Fresnel effect
        texColor.rgb += sunVisible == 1? daylight * smoothstep(0.6, 1.8, fresnel) : 0;
        // Darken shadows, scaled up with daylight and scaled down if the reflection is glowing
        texColor.rgb *= sunVisible != 1 && ssrGlow == 0.0 && skyGlow == 0.0? 1.0 - 0.2 * smoothstep(0.5, 1.0, daylight) : 1;
		texColor.a *= sunVisible != 1? 0.4 : 0.5 + fresnel;
        // Clamp blue to green so sky blue doesn't overwhelm water color
        texColor.b -= skyHit? clamp(texColor.b - texColor.g, 0, 1) * 0.5 : 0;
        // Clamp all colors so reflections never seem brighter than the sky. 
        float tintLimit = max(max(max(skyColor.r, skyColor.g), skyColor.b), ssrGlow);
        texColor.rgb = min(texColor.rgb, daylight > 0.5? tintLimit : 1);
        // Sun specular
        texColor.rgb += sunSpecular*sunColor*(0.8 + 3*smoothstep(0, 180, distanceToPlayer))*cloudCover;
		texColor.a += 2 * sunSpecular + smoothstep(0.4, 1.3, sunSpecular) * cloudCover;
        // Exaggerate raindrops
        texColor.rgb += rainy? tintLimit*(0.5 + 0.5 * smoothstep(0, 25, distanceToPlayer)) : 0;
		texColor.a += rainy? 0.2 : 0;
	} else {
        // Fade to murk based on depth and distance. Use fresnel for distance so the waves are visible.
        vec3 depthColor = waterMurkinessColor  * vec3(0.5, 0.9, 0.9) * smoothstep(-25, -3, -wsPosition.y);
        texColor.rgb = mix(texColor.rgb, depthColor, smoothstep(-0.1, 0.2, fresnel*smoothstep(2, 10, wsPosition.y)));
		texColor.b -= clamp(texColor.b - texColor.g, 0, 1) * 0.3;
        texColor.a *= smoothstep(-20, -10, -wsPosition.y);
        // Sun specular
        texColor.rgb += daylight*sunSpecular * mix(sunColor,waterMurkinessColor, 0.6);
    }
    // Brighten celestial light sources, moreso at night
    texColor.a *= 1 + skyGlow * (3 - 2.2 * smoothstep(0.5, 1.0, daylight));
    // If ssr hit glowing, increase alpha.
    texColor.a *= 1 + 2.5 * ssrGlow;
    // If drawing over glow, decrease alpha.
    texColor.a *= 1 - texture(glowColor, UV).r;

    texColor.a *= underwater > 0? 1 : reflectionStrength;
}
