#version 460

#include screenuniformbuffer.ash
#include camerauniformbuffer.ash

#include chunkcommanddraw.vsh

layout(std430, binding = UNIFORMSSBO_BINDING) readonly buffer uniformSSBO {
    ChunkUniformData[] chunkUniformData;
};
layout(std430, binding = DRAWSSBO_BINDING) readonly buffer drawSSBO {
    DrawCommandData[] drawCommandData;
};
layout(location=0) in uint voxelData;

void main() {
    vec3 voxelIdx = getPos(voxelData);

    DrawCommandData drawData = drawCommandData[gl_BaseInstance];
    ChunkUniformData chunkData = chunkUniformData[drawData.chunkIndex];
    vec3 chunkOffset = vec3(chunkData.x, chunkData.y, chunkData.z);
    blockRadius = lodRadii[chunkData.lod];
    invBlockRadius = 1 / blockRadius;
    
    voxelToOrigin = voxelIdx + chunkOffset + vec3(blockRadius);
    vec4 position;
    vec3 cameraToVoxel;
    position = camera_uniforms.MVPMatrix * vec4(voxelToOrigin, 1);
    cameraToVoxel = voxelToOrigin - rayOrigin;

    visibleFaces = getVisibleFaces(cameraToVoxel, voxelData);
    if(visibleFaces.x == 0 && visibleFaces.y == 0 && visibleFaces.z == 0) { gl_PointSize = 0; gl_Position = vec4(-1,-1,-1,-1); return; }

    // The paper says if area is >20px: Compute the line segments of the edges; Clip each edge against the near plane; compute the AABB of the vertices after clipping
    // This is just a near plane clip hack, if this is ever relevant revisit the paper.
    if(position.z < blockRadius) { gl_Position = vec4(-1,-1,-1,-1); gl_PointSize = 0; return; }

    float pointSize = 1;
    quadricProj(voxelToOrigin, blockRadius, camera_uniforms.MVPMatrix, screen_uniforms.screenSize, position, pointSize);
    stochasticCull(pointSize, position);

    gl_Position = position;
	gl_PointSize = pointSize;
}
