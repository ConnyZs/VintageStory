#version 460

//! #define OUTCOLOR_LOCATION

#include chunkcommanddraw.fsh

layout(location = OUTCOLOR_LOCATION) out vec4 outColor;

uniform vec3 cameraToOrigin;

uniform mat4 rayMatrix;

#define CUBETOSPHERE 1.732051

void main() {
    // can probably be optimized
    bvec3 visible = bvec3(visibleFaces.x != 0, visibleFaces.y != 0, visibleFaces.z != 0);

    // Calculate perspective camera ray
    vec4 pixelWorldPos = rayMatrix * vec4(gl_FragCoord.xy, -1, 1);
	pixelWorldPos /= pixelWorldPos.w;
	vec3 rayDir = normalize(pixelWorldPos.xyz - cameraToOrigin);
    vec3 rayOrigin = cameraToOrigin;

    /* Maybe figure out whether this can work for perspective?
    vec3 camRight = vec3(rayMatrix[0][0], rayMatrix[1][0], rayMatrix[2][0]);
    vec3 camUp = vec3(rayMatrix[0][1], rayMatrix[1][1], rayMatrix[2][1]);
    float spriteToWorld = blockRadius * CUBETOSPHERE - 0.01; 
    float worldX = gl_PointCoord.x * 2 - 1;
	float worldY = gl_PointCoord.y * 2 - 1;
    rayDir = normalize(voxelToOrigin - cameraToOrigin + spriteToWorld * (camRight * worldX + camUp * worldY));
    rayOrigin = cameraToOrigin;
    */

    float dist;
    vec3 normal;
    bool hit = false;
    hit = testRayIntersects(rayOrigin, rayDir, dist, normal, false, false, false, visible);

    if(!hit) { discard; }
    outColor = vec4(abs(normal), 1);
}
