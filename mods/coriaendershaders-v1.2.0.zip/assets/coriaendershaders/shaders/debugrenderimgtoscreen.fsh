#version 430

in vec2 vUV;
in vec3 eyeDirection;

//! #define DEBUGNEAR_BINDING 6
//! #define DEBUGFAR_BINDING 7

layout(binding=DEBUGNEAR_BINDING, rgba16f) uniform image2DArray debugnearimg;
layout(binding=DEBUGFAR_BINDING, rgba16f) uniform image2DArray debugfarimg;

uniform int enabled = 1;

#include screenuniformbuffer.ash

uniform float xOffset = 0;
uniform float yOffset = 0;

uniform int texLayer;

layout(location=0) out vec4 outColor;


void main() {
    ivec2 texPos = ivec2(gl_FragCoord.xy);
    vec2 texSize = texLayer < 2? vec2(imageSize(debugnearimg)) : vec2(imageSize(debugfarimg));
    float s = max(texSize.x / screen_uniforms.screenSize.x, texSize.y / screen_uniforms.screenSize.y);
    texPos = ivec2(texPos.x * s, texPos.y * s);
    //vec2 uv = texPos / screenSize;

    outColor = imageLoad(
        texLayer < 2? debugnearimg : debugfarimg,
        ivec3(texPos + ivec2(xOffset, yOffset), texLayer % 2)
    );

    //outColor = vec4(1,0,1,1);
}
