#version 430
//! #define FRAGDEPTH_UNIT 0

#include screenuniformbuffer.ash

in vec2 vUV;

layout(binding = FRAGDEPTH_UNIT) uniform sampler2D fragDepth;
//uniform sampler2D csOrig;

layout(location = 0) out vec4 lDepth;


// From fogandlight.fsh, but keep in zFar to match csOrig
float linearDepth(float depthSample)
{
    depthSample = 2.0 * depthSample - 1.0;
    float zLinear = 2.0 * screen_uniforms.zNear * screen_uniforms.zFar / (
        screen_uniforms.zFar + screen_uniforms.zNear - depthSample * (screen_uniforms.zFar - screen_uniforms.zNear)
    );
    return zLinear;
}

void main()
{
    float frag = texture(fragDepth, vUV).x;
    //float water = texture(csOrig, vUV).z;

    // Without liquid depth waterfalls won't be detected by rays, but they don't match exactly
    //lDepth = vec4(vec3(min(liquid, linearDepth(frag)), 1);

    lDepth = vec4(vec3(linearDepth(frag)), 1);
}
