#version 430

layout(location=0) in vec3 xyz;

uniform mat4 mvpMatrix;
uniform vec3 frustumCenter;

out vec3 vColor;

void main()
{
    vColor = xyz == frustumCenter? vec3(1) : vec3(
        xyz.y < frustumCenter.y? 1 : 0,
        xyz.y > frustumCenter.y? 1 : 0,
        xyz.x > frustumCenter.x? 1 : 0
    );

    gl_Position = mvpMatrix * vec4(xyz, 1);
    gl_PointSize = 50;
}
