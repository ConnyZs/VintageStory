#version 430

//! #define DEBUGNEAR_BINDING 6
//! #define DEBUGFAR_BINDING 7

layout(binding=DEBUGNEAR_BINDING, rgba16f) uniform image2DArray debugNear;
layout(binding=DEBUGFAR_BINDING, rgba16f) uniform image2DArray debugFar;

in vec3 vColor;
uniform int layer;

void main() {
    imageStore(layer < 2? debugNear : debugFar, ivec3(gl_FragCoord.xy, layer % 2), vec4(vColor, 1));
}
