#version 460

//! #define ZRANGE 1000

#include chunkcommanddraw.fsh

layout(depth_greater) out float gl_FragDepth;

//layout(location=0) out vec4 debugTex;

in float spriteToWorld;
flat in int mapLayer;

uniform mat4 rayMatrix;

void main() {
    // can probably be optimized
    bvec3 visible = bvec3(visibleFaces.x != 0, visibleFaces.y != 0, visibleFaces.z != 0);

    // Calculate orthographic camera ray
	vec3 camRight   = vec3(rayMatrix[0][0], rayMatrix[1][0], rayMatrix[2][0]);
	vec3 camUp      = vec3(rayMatrix[0][1], rayMatrix[1][1], rayMatrix[2][1]);
	vec3 camForward = vec3(rayMatrix[0][2], rayMatrix[1][2], rayMatrix[2][2]);
    float worldX = 2 * gl_PointCoord.x - 1;
    float worldY = -2 * gl_PointCoord.y + 1;
	vec3 rayOrigin = spriteToWorld * (camForward + camRight * worldX + camUp * worldY);
	vec3 rayDir = -camForward;

    float dist;
    vec3 normal;
    bool hit = false;
    hit = testRayIntersects(rayOrigin, rayDir, dist, normal, false, false, true, visible);

    float depth = gl_FragCoord.z + (dist + 0.1) / ZRANGE;
    gl_FragDepth = hit? depth : 1.0;
    // Awful for performance! Don't leave this on!
    //if(hit) debugTex = vec4(abs(normal),1);
}
