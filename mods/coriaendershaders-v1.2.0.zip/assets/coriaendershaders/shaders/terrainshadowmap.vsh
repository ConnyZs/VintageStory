#version 460

#include chunkcommanddraw.vsh

layout(std430, binding=3) readonly buffer uniformSSBO {
    ChunkUniformData[] chunkUniformData;
};
layout(std430, binding=4) readonly buffer drawSSBO {
    DrawCommandData[] drawCommandData;
};
layout(location=0) in uint voxelData;

double DistanceToPlane(vec4 plane, vec3 point) {
    return plane.x*point.x + plane.y*point.y + plane.z*point.z + plane.w;
}

uniform mat4 MVPMatrixes[4];
uniform mat4 cullingPlanes[4];
uniform vec4 extraSlicePlane;
uniform vec2 mapSizes;
out float spriteToWorld;
flat out int mapLayer;

void main() {
    vec3 voxelIdx = getPos(voxelData);

    DrawCommandData drawData = drawCommandData[gl_BaseInstance];
    ChunkUniformData chunkData = chunkUniformData[drawData.chunkIndex];
    vec3 chunkOffset = vec3(chunkData.x, chunkData.y, chunkData.z);
    blockRadius = lodRadii[chunkData.lod];
    
    voxelToOrigin = voxelIdx + chunkOffset + vec3(blockRadius);
    vec4 position;
    vec3 cameraToVoxel;
    mapLayer = int(drawData.layer);
    gl_Layer = mapLayer % 2;
    position = MVPMatrixes[mapLayer] * vec4(voxelToOrigin, 1);
    cameraToVoxel = rayOrigin;

    // Frustum cull
    bool inFrustum = true;
    inFrustum = inFrustum && DistanceToPlane(cullingPlanes[mapLayer][0], voxelToOrigin) >= -blockRadius;
    inFrustum = inFrustum && (mapLayer > 0 || DistanceToPlane(extraSlicePlane, voxelToOrigin) >= -blockRadius);
    inFrustum = inFrustum && DistanceToPlane(cullingPlanes[mapLayer][1], voxelToOrigin) >= -blockRadius;
    inFrustum = inFrustum && DistanceToPlane(cullingPlanes[mapLayer][2], voxelToOrigin) >= -blockRadius;
    inFrustum = inFrustum && DistanceToPlane(cullingPlanes[mapLayer][3], voxelToOrigin) >= -blockRadius;
    if (!inFrustum) {
		gl_Position = vec4(-1,-1,-1,-1);
        gl_PointSize = 1;
        return;
	}

    visibleFaces = getVisibleFaces(cameraToVoxel, voxelData);
    if(visibleFaces.x == 0 && visibleFaces.y == 0 && visibleFaces.z == 0) { gl_PointSize = 0; gl_Position = vec4(-1,-1,-1,-1); return; }

    float pointSize = 1;
    ivec2 mapSize = ivec2(mapSizes[mapLayer / 2]);
    quadricProj(voxelToOrigin, blockRadius, MVPMatrixes[mapLayer], mapSize, position, pointSize);

    stochasticCull(pointSize, position);

    spriteToWorld = blockRadius * CUBETOSPHERE;
    // Bias the intersection test. Probably an empirical way to do this based on texel size.
    blockRadius += mapLayer > 1? 0.03 : 0.005;
    invBlockRadius = 1 / blockRadius;

    gl_Position = position;
	gl_PointSize = pointSize;
}
