// Implementation of https://jcgt.org/published/0003/04/04/paper.pdf
// -*- c++ -*-
// Copyright (c) 2014, Morgan McGuire and Michael Mara
// All rights reserved.
//
// From McGuire and Mara, Efficient GPU Screen-Space Ray Tracing, 
// Journal of Computer Graphics Techniques, 2014
//
// This software is open source under the "BSD 2-clause license":
//
//    Redistribution and use in source and binary forms, with or
//    without modification, are permitted provided that the following
//    conditions are met:
//
//    1. Redistributions of source code must retain the above
//    copyright notice, this list of conditions and the following
//    disclaimer.
//
//    2. Redistributions in binary form must reproduce the above
//    copyright notice, this list of conditions and the following
//    disclaimer in the documentation and/or other materials provided
//    with the distribution.
//
//    THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND
//    CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
//    INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
//    MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
//    DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR
//    CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
//    SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
//    LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
//    USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
//    AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
//    LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING
//    IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF
//    THE POSSIBILITY OF SUCH DAMAGE.

#version 430

//! #define GBUFFERIN_UNIT 0
//! #define CAMERADEPTH_UNIT 1
//! #define GBUFFEROUT_LOCATION 0

#define PI 3.14159

layout(early_fragment_tests) in;

#include screenuniformbuffer.ash
#include camerauniformbuffer.ash

//in vec3 vPosition;
in vec2 vUV;
in vec3 eyeDirection;

layout(binding = CAMERADEPTH_UNIT) uniform sampler2D cameraDepth;
layout(binding = GBUFFERIN_UNIT) uniform sampler2D gBufferIn;

uniform float viewDistance;
uniform float cameraPitch;

uniform float stride;
uniform float maxSteps;
uniform float maxDistance;

layout(location = GBUFFEROUT_LOCATION) out vec4 gBufferOut;

float distanceSquared(vec2 a, vec2 b) {
    a -= b;
    return dot(a, a);
}

void swap(float a, float b) {
    float temp = a;
    a = b;
    b = temp;
}

vec2 CalculateSSRPixel(vec3 positionData, vec3 directionData) {
    vec2 hitPixel = vec2(-1);
    vec3 csOrig = positionData;
    vec3 csDir = directionData;

    // Clip to the near plane (enforces the k calculation won't divby0) and slightly past the view distance
	float maxRayDepth = csOrig.z + csDir.z * maxDistance;
	float rayLength = maxRayDepth < -viewDistance? maxDistance + (maxRayDepth + viewDistance)
        : maxRayDepth > screen_uniforms.zNear? (screen_uniforms.zNear - csOrig.z) / csDir.z : maxDistance;
    vec3 csEndPoint = csOrig + csDir.xyz * rayLength;

    // Project into pixel space
    vec4  H0 = camera_uniforms.cameraToPixelMatrix * vec4(csOrig, 1.0);      // H0/1: Homogenous projection of ray in pixel space
    vec4  H1 = camera_uniforms.cameraToPixelMatrix * vec4(csEndPoint, 1.0);
    float k0 = 1.0 / H0.w;                                                     // k0/1: kernel coefficient
    float k1 = 1.0 / H1.w;

    // Pixel space endpoints
    vec2 P0 = H0.xy * k0;
    vec2 P1 = H1.xy * k1;

    P1 += vec2((distanceSquared(P0, P1) < 0.0001) ? 0.01 : 0.0);
    vec2 delta = P1 - P0;

    bool permute = false;
    if (abs(delta.x) < abs(delta.y)) {
        permute = true;
        delta = delta.yx;
        P0 = P0.yx;
        P1 = P1.yx;
    }
    delta.x = round(delta.x);

    float stepDir = sign(delta.x);
    float invdx = stepDir / delta.x;

    float dk = (k1 - k0) * invdx;
    vec2 dP = vec2(stepDir, delta.y * invdx);

	// If skipping pixels, add a starting offset to counteract banding
	if(stride > 1) {
		dP *= stride;
		dk *= stride;
		ivec2 c = ivec2(gl_FragCoord.xy);
		float jitter = float((c.x + c.y)&1) * 0.5;
		P0 += dP * jitter;
		k0 += dk * jitter;
	}
    float prevZMaxEstimate = -csOrig.z;
    float end = P1.x * stepDir;
    float stepCount = 0.0;

    // Sometimes shallow water is closer than the terrain under it. Z fighting maybe?
	float T0 = texelFetch(cameraDepth, ivec2(gl_FragCoord), 0).r;
	float depthBias = T0 - 1 < -csOrig.z? T0 - 1 + csOrig.z : 0;

    vec4 k = vec4(k0 + dk*0.5, k0 + dk*1.5, k0 + dk*2.5, k0 + dk*3.5);
    vec4 rayZMax = vec4(prevZMaxEstimate);
    vec4 rayZMin = vec4(prevZMaxEstimate);
    vec4 sceneZMin = rayZMax + 1e4;

    // March 4 pixels per loop to overlap texture fetch latency
    // See https://developer.nvidia.com/blog/the-peak-performance-analysis-method-for-optimizing-any-gpu-workload/#appendix2
    float batch = 4;
    float bdk = batch*dk;
    vec2 bdP = batch*dP;
	vec2 dHP = permute? dP.yx : dP;

    bool sceneHit = false;
    mat4x2 hitPixels;

    // The main ray marching loop
    for (vec2 P = P0;
        ((P.x * stepDir) <= end) &&
        (stepCount < maxSteps) &&
        (sceneZMin[0] != 0.0);
        P += bdP, k += bdk, stepCount += batch
    )
    {
        hitPixels[0] = permute ? P.yx : P;
		hitPixels[1] = hitPixels[0] + dHP;
		hitPixels[2] = hitPixels[1] + dHP;
		hitPixels[3] = hitPixels[2] + dHP;

        // Project back from homogenous to camera space. Compute the value at 1/2 pixel into the future.
		rayZMax = depthBias + 1 / k;
		rayZMin = vec4(prevZMaxEstimate, rayZMax.xyz);
        prevZMaxEstimate = rayZMax[3];

        // Camera space z of the background (value is positive in -z direction)
		sceneZMin[0] = texelFetch(cameraDepth, ivec2(hitPixels[0]), 0).r;
		sceneZMin[1] = texelFetch(cameraDepth, ivec2(hitPixels[1]), 0).r;
        sceneZMin[2] = texelFetch(cameraDepth, ivec2(hitPixels[2]), 0).r;
        sceneZMin[3] = texelFetch(cameraDepth, ivec2(hitPixels[3]), 0).r;

        float rayDist = rayZMax[0] + csOrig.z;
        float zThickness = (0.1 + smoothstep(2, 5, rayDist) + 12 * smoothstep(0.4, 16.0, rayDist * 0.2));
		if( rayZMax[0] >= sceneZMin[0] && rayZMin[0] <= sceneZMin[0] + zThickness ) { hitPixel = hitPixels[0]; sceneHit = sceneZMin[0] < 550; break; }
		if( rayZMax[1] >= sceneZMin[1] && rayZMin[1] <= sceneZMin[1] + zThickness ) { hitPixel = hitPixels[1]; sceneHit = sceneZMin[1] < 550; break; }
		if( rayZMax[2] >= sceneZMin[2] && rayZMin[2] <= sceneZMin[2] + zThickness ) { hitPixel = hitPixels[2]; sceneHit = sceneZMin[2] < 550; break; }
		if( rayZMax[3] >= sceneZMin[3] && rayZMin[3] <= sceneZMin[3] + zThickness ) { hitPixel = hitPixels[3]; sceneHit = sceneZMin[3] < 550; break; }

    }
    // Discard hits off the end of the ray
	vec2 PF = permute? hitPixel.yx : hitPixel;
	sceneHit = sceneHit && PF.x < end;

	// Stride>1 usually isn't aligned with the end of the ray. If the loop failed, double check the last pixel.
	if(!sceneHit && stride > 1) {
		hitPixel = permute? P1.yx : P1;
		float rayZMax = -csEndPoint.z;
		float sceneZMin  = texelFetch(cameraDepth, ivec2(hitPixel),  0).r;
		sceneHit = rayZMax > sceneZMin && rayZMin[0] <= sceneZMin + 50;
	}

    hitPixel = sceneHit? hitPixel : vec2(-1);
    return hitPixel;
}

/* gBuffer In
rg - cs reflection normal x, y; g integral==1: is rain ripple
b - lighting data
a - camera space depth; 0: do not draw; sign: sign of reflection normal z
*/
void main() {
    vec4 gBufferData = texelFetch(gBufferIn, ivec2(gl_FragCoord.xy), 0);
    float csDirY = fract(abs(gBufferData.g)) * sign(gBufferData.g);
    vec3 csPosition = eyeDirection * abs(gBufferData.a);
    float z = sqrt(1 - pow(gBufferData.r, 2) - pow(csDirY, 2)) * sign(gBufferData.a);
    vec3 csDirection  = vec3(gBufferData.r, csDirY, z);

    #if CS_EDGEADJUST_ENABLED > 0
    // Bend the reflection near the edge so near misses with the camera pictched down don't make as harsh of a transition to sky
    vec2 xz = csDirection.z * vec2(csPosition.x / csPosition.z, 1);
    vec3 orthoReflect = normalize(vec3(xz.x, csDirection.y, xz.y));
    float distToScreenSide = cameraPitch < PI? 0 : abs(vUV.x - 0.5);
	csDirection = normalize(mix(csDirection, orthoReflect, smoothstep(0.4, 0.5, distToScreenSide)));
    #endif

    vec2 hitPixel = CalculateSSRPixel(csPosition.xyz, csDirection.xyz);

	bool xHit = hitPixel.x > 1 && hitPixel.x <= screen_uniforms.screenSize.x;
    bool yHit = hitPixel.y > 1 && hitPixel.y <= screen_uniforms.screenSize.y;

    if(!xHit || !yHit) { gBufferOut = gBufferData; return; }

    /* gBuffer Out
    rg - REPLACE(if SSR hit): SSR pixel coord x, y
    ba - PASS
    */
    gBufferOut = vec4(hitPixel, gBufferData.ba);
}
