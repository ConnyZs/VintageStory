#version 330

layout(location=0) in vec3 xyz;
layout(location=1) in vec2 uv;

out vec2 vUV;

void main()
{
    gl_Position = vec4(xyz, 1);
    vUV = uv;
}
