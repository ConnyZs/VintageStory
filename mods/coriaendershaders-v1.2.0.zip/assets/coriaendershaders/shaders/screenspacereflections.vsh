#version 430

#include screenuniformbuffer.ash

layout(location=0) in vec3 xyz;
layout(location=1) in vec2 uv;

out vec2 vUV;
out vec3 eyeDirection;
//out vec3 vPosition;

void main()
{
    gl_Position = vec4(xyz, 1);
    vUV = uv;

    // Calculate eye space direction  (https://wikis.khronos.org/opengl/Compute_eye_space_from_window_space)
    eyeDirection = vec3((2.0 * screen_uniforms.halfSizeNearPlane * uv) - screen_uniforms.halfSizeNearPlane, -1.0);
}
