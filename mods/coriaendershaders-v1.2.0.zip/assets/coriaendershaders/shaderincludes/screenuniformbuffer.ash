//? #version 430
//! #define SCREEN_UNIFORMS_BINDING 1

layout(std140, binding = SCREEN_UNIFORMS_BINDING) uniform ScreenBlock
{
    float zNear;
    float zFar;
    ivec2 screenSize;
    vec2 halfSizeNearPlane;
} screen_uniforms;
