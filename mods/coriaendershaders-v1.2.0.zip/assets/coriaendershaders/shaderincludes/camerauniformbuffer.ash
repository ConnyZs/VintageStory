//! #version 430
//! #define CAMERA_UNIFORMS_BINDING 2

layout(std140, binding = CAMERA_UNIFORMS_BINDING) uniform CameraBlock {
    mat4 modelViewMatrix;
    mat4 invModelViewMatrix;
    mat4 projectionMatrix;
    mat4 cameraToPixelMatrix;
    mat4 worldToPixelMatrix;
    vec3 sunPosition;
} camera_uniforms; 
