
struct Box {
    vec3 center;
    vec3 radius;
    vec3 invRadius;
    mat3 rotation; // object-to-world, invRayDir unused if oriented
};

struct Ray {
	vec3 origin;
	vec3 direction;
};

float maxComponent(vec3 v) { return max (max(v.x, v.y), v.z); }

// Majercik et al https://jcgt.org/published/0007/03/04/paper.pdf
// vec3 box.radius:       independent half-length along the X, Y, and Z axes
// mat3 box.rotation:     box-to-world rotation (orthonormal 3x3 matrix) transformation
// bool rayCanStartInBox: if true, assume the origin is never in a box. GLSL optimizes this at compile time
// bool oriented:         if false, ignore box.rotation
bool boxIntersection(Box box, Ray ray, out float dist, out vec3 normal, const bool rayCanStartInBox, const in bool oriented, in bool orthogonal, in vec3 invRayDirection, in bvec3 visible) {

    // Move to the box's reference frame. This is unavoidable and un-optimizable.
    // When orthogonal we can leave everything at the origin to begin with
    if(!orthogonal) {
        ray.origin = box.rotation * (ray.origin - box.center);
        if (oriented) {
            ray.direction = ray.direction * box.rotation;
        }
    }

    // This "rayCanStartInBox" branch is evaluated at compile time because `const` in GLSL
    // means compile-time constant. The multiplication by 1.0 will likewise be compiled out
    // when rayCanStartInBox = false.
    float winding;
    if (rayCanStartInBox) {
        // Winding direction: -1 if the ray starts inside of the box (i.e., and is leaving), +1 if it is starting outside of the box
        winding = (maxComponent(abs(ray.origin) * box.invRadius) < 1.0) ? -1.0 : 1.0;
    } else {
        winding = 1.0;
    }

    // We'll use the negated sign of the ray direction in several places, so precompute it.
    // The sign() instruction is fast...but surprisingly not so fast that storing the result
    // temporarily isn't an advantage.
    vec3 sgn = -sign(ray.direction);

    // Ray-plane intersection. For each pair of planes, choose the one that is front-facing
    // to the ray and compute the distance to it.
    vec3 distanceToPlane = box.radius * winding * sgn - ray.origin;
    if (oriented) {
        distanceToPlane /= ray.direction;
    } else {
        distanceToPlane *= invRayDirection;
    }

    // Perform all three ray-box tests and cast to 0 or 1 on each axis. 
    // Use a macro to eliminate the redundant code (no efficiency boost from doing so, of course!)
    // Could be written with 
#   define TEST(U, VW)\
         /* Is there a hit on this axis in front of the origin? Use multiplication instead of && for a small speedup */\
         (distanceToPlane.U >= 0.0) && \
         /* Is that hit within the face of the box? */\
         all(lessThan(abs(ray.origin.VW + ray.direction.VW * distanceToPlane.U), box.radius.VW))

    bvec3 test = bvec3(visible.x && TEST(x, yz), visible.y && TEST(y, zx), visible.z && TEST(z, xy));

    // CMOV chain that guarantees exactly one element of sgn is preserved and that the value has the right sign
    sgn = test.x ? vec3(sgn.x, 0.0, 0.0) : (test.y ? vec3(0.0, sgn.y, 0.0) : vec3(0.0, 0.0, test.z ? sgn.z : 0.0));    
#   undef TEST

    // At most one element of sgn is non-zero now. That element carries the negative sign of the 
    // ray direction as well. Notice that we were able to drop storage of the test vector from registers,
    // because it will never be used again.

    // Mask the distance by the non-zero axis
    // Dot product is faster than this CMOV chain, but doesn't work when distanceToPlane contains nans or infs. 
    //
    dist = (sgn.x != 0.0) ? distanceToPlane.x : ((sgn.y != 0.0) ? distanceToPlane.y : distanceToPlane.z);

    // Normal must face back along the ray. If you need
    // to know whether we're entering or leaving the box, 
    // then just look at the value of winding. If you need
    // texture coordinates, then use box.invDirection * hitPoint.
    
    if (oriented) {
        normal = box.rotation * sgn;
    } else {
        normal = sgn;
    }
    
    return (sgn.x != 0) || (sgn.y != 0) || (sgn.z != 0);
}

in vec3 voxelToOrigin;
in vec3 visibleFaces;
in float blockRadius;
in float invBlockRadius;

bool testRayIntersects(vec3 rayOrigin, vec3 rayDir, out float dist, out vec3 normal, const bool rayCanStartInBox, const in bool oriented, in bool orthogonal, in bvec3 visible) {
    Box box;
    box.center = voxelToOrigin;
    box.radius = vec3(blockRadius);
    box.invRadius = vec3(invBlockRadius);
    box.rotation = mat3(1.0); // I don't think this is used but still seems wrong. Identity, surely?

    Ray ray;
    ray.origin = rayOrigin;
    ray.direction = rayDir;
    vec3 invRayDirection = 1 / ray.direction;

    return boxIntersection(box, ray, dist, normal, false, false, orthogonal, invRayDirection, visible);
}    
