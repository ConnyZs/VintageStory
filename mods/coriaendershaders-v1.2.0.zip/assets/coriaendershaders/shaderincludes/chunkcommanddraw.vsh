
#extension GL_ARB_shader_draw_parameters : enable
#extension GL_ARB_shader_viewport_layer_array : enable

#define POSXBIT 27
#define NEGXBIT 29
#define POSYBIT 30
#define NEGYBIT 31
#define POSZBIT 28
#define NEGZBIT 26
#define CUBETOSPHERE 1.732051

struct ChunkUniformData {
    float x;
    float y;
    float z;
    int lod;
};
struct DrawCommandData {
    uint count;
    uint instanceCount;
    uint firstVertex;
    uint baseInstance;
    uint chunkIndex;
    uint layer;
};

const float lodRadii[6] = float[](16.0, 8.0, 4.0, 2.0, 1.0, 0.5);
uniform vec3 rayOrigin;

out vec3 voxelToOrigin;
out vec3 visibleFaces;
out float blockRadius;
out float invBlockRadius;

const uint mask = 0x1Fu;
vec3 getPos(uint pos) {
    return vec3(
        pos       & mask,
        pos >> 10 & mask,
        pos >> 5  & mask
    );
}

// From Majercik et al, who cites "GPU-Based Ray-Casting of Quadratic Surfaces" http://dl.acm.org/citation.cfm?id=2386396
void quadricProj(in vec3 osPosition, in float voxelSize, in mat4 objectToScreenMatrix, in ivec2 screenSize, inout vec4 position, inout float pointSize) {
	const vec4 quadricMat = vec4(1.0, 1.0, 1.0, -1.0);
	float sphereRadius = voxelSize * CUBETOSPHERE;
	vec4 sphereCenter = vec4(osPosition.xyz, 1.0);
	mat4 modelViewProj = transpose(objectToScreenMatrix);
	mat3x4 matT = mat3x4( mat3(modelViewProj[0].xyz, modelViewProj[1].xyz, modelViewProj[3].xyz) * sphereRadius);
	matT[0].w = dot(sphereCenter, modelViewProj[0]);
	matT[1].w = dot(sphereCenter, modelViewProj[1]);
	matT[2].w = dot(sphereCenter, modelViewProj[3]);
	mat3x4 matD = mat3x4(matT[0] * quadricMat, matT[1] * quadricMat, matT[2] * quadricMat);
	vec4 eqCoefs = vec4(dot(matD[0], matT[2]), dot(matD[1], matT[2]), dot(matD[0], matT[0]), dot(matD[1], matT[1])) / dot(matD[2], matT[2]);
	vec4 outPosition = vec4(eqCoefs.x, eqCoefs.y, 0.0, 1.0);
	vec2 AABB = sqrt(eqCoefs.xy*eqCoefs.xy - eqCoefs.zw);
	AABB *= screenSize;
	position.xy = outPosition.xy * position.w;
	pointSize = max(AABB.x, AABB.y);
}

vec3 getVisibleFaces(vec3 cameraToVoxel, uint voxelData) {
    return vec3(
        cameraToVoxel.x < 0? (voxelData >> POSXBIT) & 1u : -float((voxelData >> NEGXBIT) & 1u),
        cameraToVoxel.y < 0? (voxelData >> POSYBIT) & 1u : -float((voxelData >> NEGYBIT) & 1u),
        cameraToVoxel.z < 0? (voxelData >> POSZBIT) & 1u : -float((voxelData >> NEGZBIT) & 1u)
    );
}

// The paper says to stochastically cull if the voxel projected area is subpixel, and compute AABB if small. But the projected area is pointSize, which
// is calculated with the AABB sphere. Estimate projected area from position maybe?
void stochasticCull(inout float pointSize, inout vec4 position) {
	float stochasticCoverage = pointSize * pointSize;
	if (stochasticCoverage < 0.8) {
		// "Cull" small voxels in a stable, stochastic way by moving past the z = 0 plane.
		// Assumes voxels are in randomized order.
		position = (gl_VertexID & 0xffff) > stochasticCoverage * (0xffff / 0.8)? vec4(-1,-1,-1,-1) : position;
        pointSize = 1.0;
	}
}
