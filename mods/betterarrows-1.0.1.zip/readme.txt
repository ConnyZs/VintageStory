what this mod changes:


crude arrow: 0 damage , 20% break chance
flint arrow: 0.5 damage, 20% break chance
obsidian arrow: 1 damage, 30% break chance (very sharp but brittle volcanic glass)
copper arrow: 1 damage , 10% break chance
tinbronze arrow: 2 damage , 8% break chance
bismuthbronze arrow: 2 damage , 7% break chance
gold arrow: 2 damage , 15% break chance (weak metal, soft bad for arrows, thereforce a bit higher break chance)
silver arrow: 2 damage , 15% break chance (weak metal, soft, bad for arrows, thereforce a bit higher break chance)
black bronze arrow: 2.5 damage , 5% break chance
iron arrow: 4 damage , 3% break chance
meteoric iron arrow: 4.5 damage , 2% break chance
steel arrow: 6 damage , 0.5% break chance (shows as 0% break chance but it can still break)