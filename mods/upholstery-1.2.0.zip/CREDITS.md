This mod would have not been possible with the help of countless other people. We stand on the shoulders of giants!

Thank you,

~Tels & Phiwa

## Thank you

First and foremost a big thank you goes to **Saraty**, **Tyron** and all the other
team members for creating such a great game!

### Testing, Feedback and Bugreporting

### Translators

* English advisors: **Ashantin**, **jjallie1**
* German: **Tels**, **Phiwa**
* Japanese: **Macoto Hino**
* Ukrainian: **DeanBro**

### Modding help

* All the people answering (our and others) questions, on the modding-help discord channel or elsewere: You are awesome!
Especially:
  + **l33tmaan**
  + **SpearAndFang**

### Resources

The mod icon and title card image are based on generations from
[AI Pixel Art Generator](https://perchance.org/ai-pixel-art-generator) with the following query:

    A dining room full of sofas and chairs with plaid patterns and royal furniture
