# Upholstery

"Craft furniture and interior decorations."

This Vintage Story mod adds more furniture and interior decorations.

## New Furniture

* Checkered chairs

We hope you enjoy our work.

~Phiwa & Tels

# Download

* The mod from [Official Vintage Story ModDB](https://mods.vintagestory.at/upholstery)
* You also need to install [Expanded Matter](https://mods.vintagestory.at/em)
* The mod from [Official Vintage Story ModDB](https://mods.vintagestory.at/tailorsdelight)
* The source code can be found on [Gitlab](https://gitlab.com/codesmiths/vs_upholstery/-/releases)

# Installation

This mod should work in existing worlds. If in doubt, please create a new world.

  <u>**Make a backup of your savegame and world before trying this mod!**</u>

If you would like to translate this mod into other languages, please [contact us](https://gitlab.com/codesmiths/vs_bricklayers/-/wikis/Contact).

# Signature key

All our releases are signed using PGP (GnuPG) and their integrity can be verified by using the public key as published
[on the wiki](https://gitlab.com/codesmiths/vs_bricklayers/-/wikis/Signing-key).

