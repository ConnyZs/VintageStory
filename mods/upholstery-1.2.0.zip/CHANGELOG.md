# v1.2.0 - 2026-05-02 - Fixer Lower

* Requires VS 1.22.0 or newer
* Requires Tailor's Delight 2.2.0 or newer

## Compatibility With VS

* #25 - Update for VS 1.22


# v1.1.1 - 2025-12-26 - More Seating Options

* Requires VS 1.21.0 or newer
* Requires Expanded Matters 3.4.0 or newer
* Requires Tailor's Delight 2.1.0 or newer

## Bugfixes

* #18 - Fix failing furniture trader patch
* #14 - Fix patch for crafting wool chairs with Wildcraft: Tree & Shrubs wood types

## New Features

* #23 - Add rush matting chair
* #22 - Reorganize internal codes for chairs to unify the JSON
* #21 - Add dark blue, brown, green and red chairs with cloth from Tailor's Delight
* #12 - Add new chair colors based on Tailor's Delight's new cloth variants
* #11 - Add leather chairs

## Compatibility With Other Mods

* #14 - Add Wool & More compatibility: craft chairs with wool
* #14 - Craft various chairs with Wildcraft: Tree & Shrubs wood types

## Compatibility With VS

* #20 - For VS 1.21 - set a higher `humanTraversalCost` so entities avoid walking over chairs
* #10 - Adapt for VS 1.20


# v1.0.1 - 2024-08-24 - Get Seated

## New Features

* #9 - Add new creative tab "Furniture"

## Translations

* #7 - Add Ukrainian translation (Thank you, DeanBro!)

## Tweaks And Balancing

* #8 - Chairs and tables only stack to 16


# v1.0.0 - 2024-06-20 - First release

## New Features

* #2 - Take over checkered chairs from Tailor's Delight

## Compatibility With Other Mods

* #3 - Add Wildcraft: Trees and Shrubs compatibility
